import { useState } from 'react';
import { Save, RotateCcw, Users, SlidersHorizontal, Info } from 'lucide-react';
import type { StoreApi } from '@/store/useStore';
import { PageContainer, SectionTitle } from '@/components/Common';
import { Avatar } from '@/components/Badges';
import { useToast } from '@/components/Toast';

interface Props {
  store: StoreApi;
}

export function SettingsPage({ store }: Props) {
  const { state, updateSettings, resetDemoData } = store;
  const { toast } = useToast();
  const [lead, setLead] = useState(state.settings.reminderLeadDays);
  const [highTask, setHighTask] = useState(state.settings.highRiskPendingTaskThreshold);
  const [medTask, setMedTask] = useState(state.settings.mediumRiskPendingTaskThreshold);
  const [highDays, setHighDays] = useState(state.settings.highRiskDaysToDeadline);
  const [medDays, setMedDays] = useState(state.settings.mediumRiskDaysToDeadline);

  const save = () => {
    updateSettings({
      reminderLeadDays: lead,
      highRiskPendingTaskThreshold: highTask,
      mediumRiskPendingTaskThreshold: medTask,
      highRiskDaysToDeadline: highDays,
      mediumRiskDaysToDeadline: medDays,
    });
    toast('Settings saved', 'success');
  };

  return (
    <PageContainer>
      <SectionTitle title="Settings" subtitle="Configure risk thresholds, reminders, and demo data" />

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <div className="card p-5">
          <div className="flex items-center gap-2 mb-3"><SlidersHorizontal className="h-5 w-5 text-blue-600" /><h3 className="font-semibold text-slate-900">Risk & Reminder Thresholds</h3></div>
          <div className="space-y-4">
            <div>
              <label className="label">Reminder lead time (days)</label>
              <input type="number" min={1} max={60} value={lead} onChange={(e) => setLead(Number(e.target.value))} className="input" />
              <p className="text-xs text-slate-500 mt-1">Show "due soon" indicator this many days before a deadline.</p>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="label">High risk: pending tasks ≥</label>
                <input type="number" min={1} value={highTask} onChange={(e) => setHighTask(Number(e.target.value))} className="input" />
              </div>
              <div>
                <label className="label">Medium risk: pending tasks ≥</label>
                <input type="number" min={1} value={medTask} onChange={(e) => setMedTask(Number(e.target.value))} className="input" />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="label">High risk: days to deadline ≤</label>
                <input type="number" min={1} value={highDays} onChange={(e) => setHighDays(Number(e.target.value))} className="input" />
              </div>
              <div>
                <label className="label">Medium risk: days to deadline ≤</label>
                <input type="number" min={1} value={medDays} onChange={(e) => setMedDays(Number(e.target.value))} className="input" />
              </div>
            </div>
            <button onClick={save} className="btn-primary"><Save className="h-4 w-4" /> Save Settings</button>
          </div>
        </div>

        <div className="space-y-4">
          <div className="card p-5">
            <div className="flex items-center gap-2 mb-3"><Users className="h-5 w-5 text-emerald-600" /><h3 className="font-semibold text-slate-900">Demo Roles & Users</h3></div>
            <div className="space-y-2">
              {state.users.map((u) => (
                <div key={u.id} className="flex items-center gap-3 p-2.5 rounded-lg bg-slate-50">
                  <Avatar name={u.name} />
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-slate-800">{u.name}</p>
                    <p className="text-xs text-slate-500">{u.email}</p>
                  </div>
                  <span className="text-xs font-medium text-slate-600 bg-white border border-slate-200 px-2 py-0.5 rounded-full">{u.role}</span>
                </div>
              ))}
            </div>
            <p className="text-xs text-slate-400 mt-3">Role-based permissions are demo-only. Real enforcement requires authentication and authorization to be implemented.</p>
          </div>

          <div className="card p-5">
            <div className="flex items-center gap-2 mb-3"><RotateCcw className="h-5 w-5 text-amber-600" /><h3 className="font-semibold text-slate-900">Reset Demo Data</h3></div>
            <p className="text-sm text-slate-500 mb-3">Restore all applications, tasks, alerts, and audit entries to the original demo state. This clears any local changes.</p>
            <button onClick={() => { if (confirm('Reset all demo data to defaults? This cannot be undone.')) { resetDemoData(); toast('Demo data reset', 'success'); } }} className="btn-danger"><RotateCcw className="h-4 w-4" /> Reset Demo Data</button>
            <p className="text-xs text-slate-400 mt-3">All data is stored locally in your browser (LocalStorage). Clearing your browser storage also resets the demo.</p>
          </div>

          <div className="card p-5 bg-blue-50/40 border-blue-200">
            <div className="flex items-center gap-2 mb-2"><Info className="h-5 w-5 text-blue-600" /><h3 className="font-semibold text-slate-900">About AICTEFlow</h3></div>
            <p className="text-sm text-slate-600 leading-relaxed">AICTEFlow is a prototype for managing approval workflows, document checklists, compliance tasks, and delay-risk monitoring. The AI Assistant is a simulated, rule-based guide. Risk levels and reminders are prototype estimates — not official AICTE decisions or guaranteed predictions. No official AICTE integration is claimed.</p>
          </div>
        </div>
      </div>
    </PageContainer>
  );
}
