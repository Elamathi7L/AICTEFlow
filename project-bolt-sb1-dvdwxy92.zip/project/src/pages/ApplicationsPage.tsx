import { useMemo, useState } from 'react';
import { Plus, Search, Eye, Trash2, Filter } from 'lucide-react';
import type { StoreState, WorkflowApp, AppStatus } from '@/types';
import { PageContainer, EmptyState, SectionTitle } from '@/components/Common';
import { StatusBadge, RiskBadge, ProgressBar } from '@/components/Badges';
import { computeRiskForApp } from '@/lib/risk';
import { missingRequiredDocs, daysToDeadline } from '@/store/useStore';
import { formatDate, relativeDays } from '@/lib/utils';
import { Modal } from '@/components/Modal';
import { useToast } from '@/components/Toast';

interface Props {
  state: StoreState;
  onOpenApp: (id: string) => void;
  onCreate: (app: WorkflowApp) => void;
  onDelete: (id: string) => void;
}

const STATUSES: AppStatus[] = ['Draft', 'Submitted', 'Under Review', 'Correction Required', 'Approved', 'Rejected'];

export function ApplicationsPage({ state, onOpenApp, onCreate, onDelete }: Props) {
  const { toast } = useToast();
  const [q, setQ] = useState('');
  const [statusFilter, setStatusFilter] = useState<AppStatus | 'All'>('All');
  const [showCreate, setShowCreate] = useState(false);

  const filtered = useMemo(() => {
    return state.applications.filter((a) => {
      if (statusFilter !== 'All' && a.status !== statusFilter) return false;
      if (q && !`${a.institutionName} ${a.id} ${a.applicationType}`.toLowerCase().includes(q.toLowerCase())) return false;
      return true;
    });
  }, [state.applications, q, statusFilter]);

  return (
    <PageContainer>
      <SectionTitle
        title="Applications"
        subtitle="Manage institution applications and track progress"
        action={
          <button onClick={() => setShowCreate(true)} className="btn-primary">
            <Plus className="h-4 w-4" /> New Application
          </button>
        }
      />

      <div className="card p-3 mb-4 flex flex-col sm:flex-row gap-2">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
          <input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Search institution, ID, or type…"
            className="input pl-9"
          />
        </div>
        <div className="flex items-center gap-2">
          <Filter className="h-4 w-4 text-slate-400" />
          <select value={statusFilter} onChange={(e) => setStatusFilter(e.target.value as AppStatus | 'All')} className="input w-auto">
            <option value="All">All statuses</option>
            {STATUSES.map((s) => <option key={s} value={s}>{s}</option>)}
          </select>
        </div>
      </div>

      {filtered.length === 0 ? (
        <EmptyState
          title="No applications found"
          description="Try a different search or filter, or create a new application."
          action={<button onClick={() => setShowCreate(true)} className="btn-primary"><Plus className="h-4 w-4" /> New Application</button>}
        />
      ) : (
        <div className="card overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-slate-50 text-slate-600 text-xs uppercase tracking-wide">
                <tr>
                  <th className="text-left font-semibold px-4 py-3">Application</th>
                  <th className="text-left font-semibold px-4 py-3 hidden md:table-cell">Type</th>
                  <th className="text-left font-semibold px-4 py-3">Status</th>
                  <th className="text-left font-semibold px-4 py-3 hidden lg:table-cell">Progress</th>
                  <th className="text-left font-semibold px-4 py-3">Deadline</th>
                  <th className="text-left font-semibold px-4 py-3">Risk</th>
                  <th className="text-right font-semibold px-4 py-3">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filtered.map((a) => {
                  const risk = computeRiskForApp(a, state.tasks, state.settings);
                  const missing = missingRequiredDocs(a).length;
                  const days = daysToDeadline(a);
                  return (
                    <tr key={a.id} className="table-row-hover">
                      <td className="px-4 py-3">
                        <button onClick={() => onOpenApp(a.id)} className="text-left">
                          <p className="font-medium text-slate-900 hover:text-blue-600">{a.institutionName}</p>
                          <p className="text-xs text-slate-500">{a.id}{missing > 0 && <span className="text-red-500"> · {missing} missing</span>}</p>
                        </button>
                      </td>
                      <td className="px-4 py-3 text-slate-600 hidden md:table-cell">{a.applicationType}</td>
                      <td className="px-4 py-3"><StatusBadge status={a.status} /></td>
                      <td className="px-4 py-3 hidden lg:table-cell">
                        <div className="flex items-center gap-2 w-32">
                          <ProgressBar value={a.progress} />
                          <span className="text-xs text-slate-500 w-8">{a.progress}%</span>
                        </div>
                      </td>
                      <td className="px-4 py-3">
                        <p className="text-slate-700">{formatDate(a.deadline)}</p>
                        <p className={`text-xs ${days < 0 ? 'text-red-600' : days <= 7 ? 'text-amber-600' : 'text-slate-500'}`}>{relativeDays(a.deadline)}</p>
                      </td>
                      <td className="px-4 py-3"><RiskBadge level={risk.level} score={risk.score} /></td>
                      <td className="px-4 py-3">
                        <div className="flex items-center justify-end gap-1">
                          <button onClick={() => onOpenApp(a.id)} className="p-1.5 rounded-md text-slate-500 hover:bg-blue-100 hover:text-blue-600" title="View">
                            <Eye className="h-4 w-4" />
                          </button>
                          <button
                            onClick={() => {
                              if (confirm(`Delete ${a.institutionName} (${a.id})? Related tasks and alerts will also be removed.`)) {
                                onDelete(a.id);
                                toast('Application deleted', 'success');
                              }
                            }}
                            className="p-1.5 rounded-md text-slate-500 hover:bg-red-100 hover:text-red-600"
                            title="Delete"
                          >
                            <Trash2 className="h-4 w-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      <CreateAppModal
        open={showCreate}
        onClose={() => setShowCreate(false)}
        onCreate={(app) => { onCreate(app); setShowCreate(false); toast('Application created', 'success'); }}
        existingTypes={[...new Set(state.applications.map((a) => a.applicationType))]}
      />
    </PageContainer>
  );
}

function CreateAppModal({
  open,
  onClose,
  onCreate,
  existingTypes,
}: {
  open: boolean;
  onClose: () => void;
  onCreate: (app: WorkflowApp) => void;
  existingTypes: string[];
}) {
  const [name, setName] = useState('');
  const [type, setType] = useState('New Institute Approval');
  const [deadline, setDeadline] = useState(() => {
    const d = new Date(); d.setDate(d.getDate() + 30);
    return d.toISOString().slice(0, 10);
  });
  const [err, setErr] = useState('');

  const submit = () => {
    if (!name.trim()) { setErr('Institution name is required.'); return; }
    if (!deadline) { setErr('Deadline is required.'); return; }
    const id = `APP-${new Date().getFullYear()}-${String(Math.floor(1000 + Math.random() * 8999))}`;
    const app: WorkflowApp = {
      id,
      institutionName: name.trim(),
      applicationType: type,
      status: 'Draft',
      createdAt: new Date().toISOString(),
      deadline: new Date(deadline + 'T23:59:59').toISOString(),
      progress: 5,
      checklist: [
        { type: 'Institution Accreditation Certificate', required: true },
        { type: 'NOC from State Government', required: true },
        { type: 'Land Documents & Ownership Proof', required: true },
        { type: 'Building Plan Approval', required: true },
        { type: 'Faculty Qualification Records', required: true },
        { type: 'Course Curriculum & Syllabus', required: true },
        { type: 'Financial Statement (Last 3 Years)', required: true },
        { type: 'Bank Statement Proof', required: false },
        { type: 'Anti-Ragging Committee Report', required: false },
        { type: 'Grievance Redressal Policy', required: false },
      ],
      documents: [],
      history: [{ status: 'Draft', date: new Date().toISOString(), note: 'Application created' }],
    };
    // Start with all required docs missing
    app.documents = app.checklist.map((c) => ({
      id: `doc-${app.id}-${c.type.replace(/[^a-zA-Z0-9]/g, '')}`,
      type: c.type,
      status: 'Missing',
      versions: [],
    }));
    onCreate(app);
    setName(''); setErr('');
  };

  return (
    <Modal
      open={open}
      onClose={onClose}
      title="Create New Application"
      footer={
        <>
          <button onClick={onClose} className="btn-secondary">Cancel</button>
          <button onClick={submit} className="btn-primary">Create</button>
        </>
      }
    >
      <div className="space-y-4">
        <div>
          <label className="label">Institution Name</label>
          <input value={name} onChange={(e) => setName(e.target.value)} className="input" placeholder="e.g. Sunrise College of Engineering" />
        </div>
        <div>
          <label className="label">Application Type</label>
          <input list="app-types" value={type} onChange={(e) => setType(e.target.value)} className="input" />
          <datalist id="app-types">
            {[...new Set(['New Institute Approval', 'Extension of Approval', 'Course Expansion', 'Closure of Institute', ...existingTypes])].map((t) => (
              <option key={t} value={t} />
            ))}
          </datalist>
        </div>
        <div>
          <label className="label">Deadline</label>
          <input type="date" value={deadline} onChange={(e) => setDeadline(e.target.value)} className="input" />
        </div>
        {err && <p className="text-sm text-red-600">{err}</p>}
        <p className="text-xs text-slate-500">The standard AICTE demo checklist will be attached. All documents start as "Missing".</p>
      </div>
    </Modal>
  );
}
