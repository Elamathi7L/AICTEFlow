import {
  FolderKanban,
  Clock,
  AlertTriangle,
  FileWarning,
  CalendarClock,
  CheckCircle2,
  Bot,
  TrendingUp,
  Activity,
} from 'lucide-react';
import type { StoreState, WorkflowApp } from '@/types';
import { StatCard, SectionTitle, PageContainer, EmptyState } from '@/components/Common';
import { StatusBadge, RiskBadge, ProgressBar } from '@/components/Badges';
import { computeRiskForApp } from '@/lib/risk';
import { daysToDeadline, missingRequiredDocs } from '@/store/useStore';
import { formatDate, relativeDays } from '@/lib/utils';
import { answerAssistant, SUGGESTED_QUESTIONS } from '@/lib/assistant';
import { useMemo, useState } from 'react';

interface Props {
  state: StoreState;
  onOpenApp: (id: string) => void;
  onNavigate: (page: 'applications' | 'calendar' | 'reports' | 'audit') => void;
}

export function Dashboard({ state, onOpenApp, onNavigate }: Props) {
  const { applications, tasks, alerts, audit } = state;
  const pendingTasks = tasks.filter((t) => !t.completed);
  const overdueTasks = pendingTasks.filter((t) => new Date(t.dueDate).getTime() < Date.now());

  const riskByApp = useMemo(() => {
    const map: Record<string, ReturnType<typeof computeRiskForApp>> = {};
    for (const a of applications) map[a.id] = computeRiskForApp(a, pendingTasks, state.settings);
    return map;
  }, [applications, pendingTasks, state.settings]);

  const awaitingReview = applications.filter((a) => a.status === 'Under Review').length;
  const corrections = applications.filter((a) => a.status === 'Correction Required').length;
  const totalMissing = applications.reduce((acc, a) => acc + missingRequiredDocs(a).length, 0);
  const upcomingDeadlines = applications.filter((a) => daysToDeadline(a) >= 0 && daysToDeadline(a) <= 14).length;
  const high = Object.values(riskByApp).filter((r) => r.level === 'High').length;
  const medium = Object.values(riskByApp).filter((r) => r.level === 'Medium').length;
  const low = Object.values(riskByApp).filter((r) => r.level === 'Low').length;

  const urgentApp = useMemo(() => {
    return [...applications].sort((a, b) => riskByApp[b.id].score - riskByApp[a.id].score)[0];
  }, [applications, riskByApp]);

  const assistantReply = useMemo(
    () => (urgentApp ? answerAssistant('What should I do next?', state, urgentApp) : null),
    [state, urgentApp],
  );

  const [selectedQ, setSelectedQ] = useState(0);
  const liveReply = useMemo(() => {
    if (!urgentApp) return null;
    return answerAssistant(SUGGESTED_QUESTIONS[selectedQ], state, urgentApp);
  }, [selectedQ, state, urgentApp]);

  const recentAlerts = alerts.slice(0, 4);
  const recentAudit = audit.slice(0, 5);

  return (
    <PageContainer>
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4 mb-6">
        <StatCard label="Total Applications" value={applications.length} icon={FolderKanban} tone="blue" />
        <StatCard label="Awaiting Review" value={awaitingReview} icon={Clock} tone="amber" />
        <StatCard label="Corrections Required" value={corrections} icon={AlertTriangle} tone="red" />
        <StatCard label="Missing Documents" value={totalMissing} icon={FileWarning} tone="violet" />
        <StatCard label="Upcoming Deadlines (14d)" value={upcomingDeadlines} icon={CalendarClock} tone="blue" />
        <StatCard label="Overdue Tasks" value={overdueTasks.length} icon={AlertTriangle} tone="red" />
        <StatCard label="High Delay-Risk Apps" value={high} icon={TrendingUp} tone="red" hint={`Med ${medium} · Low ${low}`} />
        <StatCard label="Completed Tasks" value={tasks.filter((t) => t.completed).length} icon={CheckCircle2} tone="emerald" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 mb-6">
        <div className="card p-4 lg:col-span-2">
          <SectionTitle title="Applications Overview" subtitle="Risk and status at a glance" action={
            <button onClick={() => onNavigate('applications')} className="btn-ghost text-xs">View all</button>
          } />
          {applications.length === 0 ? (
            <EmptyState title="No applications yet" description="Create your first application to see it here." />
          ) : (
            <div className="space-y-2">
              {applications.slice(0, 5).map((a) => {
                const r = riskByApp[a.id];
                return (
                  <button
                    key={a.id}
                    onClick={() => onOpenApp(a.id)}
                    className="w-full text-left flex items-center gap-3 p-3 rounded-lg border border-slate-200 hover:border-blue-300 hover:bg-blue-50/30 transition-colors"
                  >
                    <div className="flex-1 min-w-0">
                      <p className="font-medium text-sm text-slate-900 truncate">{a.institutionName}</p>
                      <p className="text-xs text-slate-500">{a.id} · {a.applicationType}</p>
                    </div>
                    <div className="hidden sm:block w-28"><ProgressBar value={a.progress} /></div>
                    <StatusBadge status={a.status} />
                    <RiskBadge level={r.level} score={r.score} />
                  </button>
                );
              })}
            </div>
          )}
        </div>

        <div className="card p-4 flex flex-col">
          <SectionTitle title="AI Assistant" subtitle="Next-step guidance (simulated)" />
          {liveReply ? (
            <div className="flex-1">
              <div className="rounded-lg bg-blue-50 border border-blue-100 p-3 mb-3">
                <div className="flex items-center gap-1.5 text-blue-600 mb-1.5">
                  <Bot className="h-4 w-4" />
                  <span className="text-xs font-semibold">For {urgentApp?.institutionName}</span>
                </div>
                <p className="text-sm text-slate-700 whitespace-pre-line leading-relaxed">{liveReply.text}</p>
              </div>
              <div className="flex flex-wrap gap-1.5">
                {SUGGESTED_QUESTIONS.map((q, i) => (
                  <button
                    key={q}
                    onClick={() => setSelectedQ(i)}
                    className={`text-[11px] rounded-full px-2 py-0.5 border transition-colors ${
                      i === selectedQ ? 'bg-blue-600 text-white border-blue-600' : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-100'
                    }`}
                  >
                    {q}
                  </button>
                ))}
              </div>
            </div>
          ) : (
            <p className="text-sm text-slate-500">No application to analyze.</p>
          )}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <div className="card p-4">
          <SectionTitle title="Recent Alerts" action={
            <button onClick={() => onNavigate('calendar')} className="btn-ghost text-xs">Calendar</button>
          } />
          {recentAlerts.length === 0 ? (
            <p className="text-sm text-slate-500 py-6 text-center">No alerts.</p>
          ) : (
            <div className="space-y-2">
              {recentAlerts.map((a) => (
                <div key={a.id} className="flex items-start gap-2 p-2.5 rounded-lg bg-slate-50">
                  <span className={`mt-0.5 h-2 w-2 rounded-full flex-shrink-0 ${a.severity === 'critical' ? 'bg-red-500' : a.severity === 'warning' ? 'bg-amber-500' : 'bg-blue-500'}`} />
                  <div className="flex-1 min-w-0">
                    <p className="text-sm text-slate-800 leading-snug">{a.message}</p>
                    <p className="text-xs text-slate-500 mt-0.5">{relativeDays(a.date)} · {a.recommendedAction}</p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="card p-4">
          <SectionTitle title="Recent Audit Activity" action={
            <button onClick={() => onNavigate('audit')} className="btn-ghost text-xs">Audit trail</button>
          } />
          {recentAudit.length === 0 ? (
            <p className="text-sm text-slate-500 py-6 text-center">No activity yet.</p>
          ) : (
            <div className="space-y-2">
              {recentAudit.map((e) => (
                <div key={e.id} className="flex items-start gap-2.5 p-2.5 rounded-lg hover:bg-slate-50">
                  <Activity className="h-4 w-4 text-slate-400 mt-0.5 flex-shrink-0" />
                  <div className="flex-1 min-w-0">
                    <p className="text-sm text-slate-800 leading-snug">{e.action}</p>
                    <p className="text-xs text-slate-500 mt-0.5">{e.actor} · {formatDate(e.timestamp)}{e.applicationId ? ` · ${e.applicationId}` : ''}</p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      <p className="text-xs text-slate-400 mt-6 text-center">
        AICTEFlow is a prototype. Risk levels, AI guidance, and reminders are simulated estimates — not official AICTE decisions or guaranteed predictions.
      </p>
    </PageContainer>
  );
}
