import { useMemo, useState } from 'react';
import { History, Search, Download } from 'lucide-react';
import type { StoreState } from '@/types';
import { PageContainer, SectionTitle, EmptyState } from '@/components/Common';
import { formatDateTime } from '@/lib/utils';
import { toCSV, downloadFile } from '@/lib/utils';

interface Props {
  state: StoreState;
  onOpenApp: (id: string) => void;
}

export function AuditPage({ state, onOpenApp }: Props) {
  const [q, setQ] = useState('');

  const filtered = useMemo(() => {
    if (!q) return state.audit;
    const lq = q.toLowerCase();
    return state.audit.filter((e) => `${e.action} ${e.actor} ${e.applicationId ?? ''} ${e.details ?? ''}`.toLowerCase().includes(lq));
  }, [state.audit, q]);

  const exportCSV = () => {
    const rows = state.audit.map((e) => ({
      Timestamp: e.timestamp,
      Actor: e.actor,
      Action: e.action,
      ApplicationID: e.applicationId ?? '',
      Details: e.details ?? '',
    }));
    downloadFile('AICTEFlow_audit_trail.csv', toCSV(rows), 'text/csv');
  };

  return (
    <PageContainer>
      <SectionTitle title="Audit Trail" subtitle="Recorded actions across the system"
        action={<button onClick={exportCSV} className="btn-secondary"><Download className="h-4 w-4" /> Export CSV</button>}
      />

      <div className="card p-3 mb-4">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
          <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search audit entries…" className="input pl-9" />
        </div>
      </div>

      {filtered.length === 0 ? (
        <EmptyState title="No audit entries" description="Actions like status changes, uploads, and task updates will appear here." />
      ) : (
        <div className="card overflow-hidden">
          <div className="divide-y divide-slate-100">
            {filtered.map((e) => (
              <div key={e.id} className="flex items-start gap-3 px-4 py-3 hover:bg-slate-50">
                <div className="h-8 w-8 rounded-full bg-slate-100 flex items-center justify-center flex-shrink-0">
                  <History className="h-4 w-4 text-slate-500" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm text-slate-800">{e.action}</p>
                  <p className="text-xs text-slate-500 mt-0.5">
                    {formatDateTime(e.timestamp)} · by {e.actor}
                    {e.applicationId && <> · <button onClick={() => onOpenApp(e.applicationId!)} className="text-blue-600 hover:underline">{e.applicationId}</button></>}
                    {e.details && <> · <span className="text-slate-400">{e.details}</span></>}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </PageContainer>
  );
}
