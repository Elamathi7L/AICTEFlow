import { useMemo, useState } from 'react';
import { Search, Upload, FileCheck2, FileX2, FileClock } from 'lucide-react';
import type { StoreState, DocumentStatus } from '@/types';
import { PageContainer, SectionTitle, StatCard, EmptyState } from '@/components/Common';
import { DocStatusBadge } from '@/components/Badges';
import { formatDate } from '@/lib/utils';
import { Modal } from '@/components/Modal';
import { useToast } from '@/components/Toast';
import type { StoreApi } from '@/store/useStore';

interface Props {
  state: StoreState;
  store: StoreApi;
  onOpenApp: (id: string) => void;
}

const FILTERS: ('All' | DocumentStatus)[] = ['All', 'Missing', 'Uploaded', 'Needs Review', 'Verified'];

export function DocumentsPage({ state, store, onOpenApp }: Props) {
  const { toast } = useToast();
  const [q, setQ] = useState('');
  const [filter, setFilter] = useState<'All' | DocumentStatus>('All');
  const [uploadTarget, setUploadTarget] = useState<{ appId: string; docId: string; type: string } | null>(null);

  const allDocs = useMemo(() => {
    return state.applications.flatMap((a) => a.documents.map((d) => ({ ...d, appId: a.id, app: a })));
  }, [state.applications]);

  const filtered = allDocs.filter((d) => {
    if (filter !== 'All' && d.status !== filter) return false;
    if (q && !`${d.type} ${d.app.institutionName} ${d.filename ?? ''}`.toLowerCase().includes(q.toLowerCase())) return false;
    return true;
  });

  const counts = {
    missing: allDocs.filter((d) => d.status === 'Missing').length,
    uploaded: allDocs.filter((d) => d.status === 'Uploaded').length,
    needsReview: allDocs.filter((d) => d.status === 'Needs Review').length,
    verified: allDocs.filter((d) => d.status === 'Verified').length,
  };

  const handleUpload = (filename: string) => {
    if (!uploadTarget) return;
    store.uploadDocument(uploadTarget.appId, uploadTarget.docId, filename, 'Current User');
    store.addAudit('Current User', `Document ${filename} uploaded`, uploadTarget.appId, uploadTarget.type);
    toast('Document uploaded', 'success');
    setUploadTarget(null);
  };

  return (
    <PageContainer>
      <SectionTitle title="Documents" subtitle="All documents across applications" />

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-4">
        <StatCard label="Missing" value={counts.missing} icon={FileX2} tone="red" />
        <StatCard label="Uploaded" value={counts.uploaded} icon={FileCheck2} tone="blue" />
        <StatCard label="Needs Review" value={counts.needsReview} icon={FileClock} tone="amber" />
        <StatCard label="Verified" value={counts.verified} icon={FileCheck2} tone="emerald" />
      </div>

      <div className="card p-3 mb-4 flex flex-col sm:flex-row gap-2">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
          <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search documents…" className="input pl-9" />
        </div>
        <div className="flex flex-wrap gap-1">
          {FILTERS.map((f) => (
            <button key={f} onClick={() => setFilter(f)} className={`text-xs px-3 py-1.5 rounded-lg border ${filter === f ? 'bg-blue-600 text-white border-blue-600' : 'bg-white text-slate-600 border-slate-300 hover:bg-slate-50'}`}>{f}</button>
          ))}
        </div>
      </div>

      {filtered.length === 0 ? (
        <EmptyState title="No documents found" description="Try a different search or filter." />
      ) : (
        <div className="card overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-slate-50 text-slate-600 text-xs uppercase">
                <tr>
                  <th className="text-left font-semibold px-4 py-3">Document</th>
                  <th className="text-left font-semibold px-4 py-3">Application</th>
                  <th className="text-left font-semibold px-4 py-3">Status</th>
                  <th className="text-left font-semibold px-4 py-3 hidden md:table-cell">Filename</th>
                  <th className="text-left font-semibold px-4 py-3 hidden sm:table-cell">Uploaded</th>
                  <th className="text-right font-semibold px-4 py-3">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filtered.map((d) => (
                  <tr key={d.id} className="table-row-hover">
                    <td className="px-4 py-3">
                      <p className="font-medium text-slate-800">{d.type}</p>
                      <p className="text-xs text-slate-500">{d.app.checklist.find((c) => c.type === d.type)?.required ? 'Required' : 'Optional'}</p>
                    </td>
                    <td className="px-4 py-3">
                      <button onClick={() => onOpenApp(d.appId)} className="text-blue-600 hover:underline text-xs">{d.appId}</button>
                      <p className="text-xs text-slate-500 truncate max-w-[160px]">{d.app.institutionName}</p>
                    </td>
                    <td className="px-4 py-3"><DocStatusBadge status={d.status} /></td>
                    <td className="px-4 py-3 text-slate-600 hidden md:table-cell">{d.filename ?? '—'}</td>
                    <td className="px-4 py-3 text-slate-500 hidden sm:table-cell">{d.uploadedAt ? formatDate(d.uploadedAt) : '—'}</td>
                    <td className="px-4 py-3 text-right">
                      {d.status === 'Missing' ? (
                        <button onClick={() => setUploadTarget({ appId: d.appId, docId: d.id, type: d.type })} className="btn-ghost text-xs px-2 py-1"><Upload className="h-3.5 w-3.5" /> Upload</button>
                      ) : (
                        <button onClick={() => onOpenApp(d.appId)} className="btn-ghost text-xs px-2 py-1">Open</button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      <Modal open={!!uploadTarget} onClose={() => setUploadTarget(null)} title="Upload Document" size="sm"
        footer={<><button onClick={() => setUploadTarget(null)} className="btn-secondary">Cancel</button><button onClick={() => { const inp = document.getElementById('upload-filename') as HTMLInputElement; if (inp?.value.trim()) handleUpload(inp.value.trim()); }} className="btn-primary">Upload</button></>}
      >
        <div className="space-y-3">
          <p className="text-sm text-slate-600">Document: <span className="font-medium">{uploadTarget?.type}</span></p>
          <div><label className="label">Filename</label><input id="upload-filename" className="input" placeholder="e.g. NOC_2026.pdf" /></div>
          <p className="text-xs text-slate-400">Demo upload — no real file stored.</p>
        </div>
      </Modal>
    </PageContainer>
  );
}
