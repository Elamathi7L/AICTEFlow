import { Download, FileText, ShieldCheck, Printer } from 'lucide-react';
import type { StoreState } from '@/types';
import type { StoreApi } from '@/store/useStore';
import { PageContainer, SectionTitle } from '@/components/Common';
import { StatusBadge, RiskBadge } from '@/components/Badges';
import { computeRiskForApp } from '@/lib/risk';
import { missingRequiredDocs, daysToDeadline } from '@/store/useStore';
import { generateReadinessReport, generateApplicationSummaryCSV } from '@/lib/report';
import { downloadFile, formatDate, toCSV } from '@/lib/utils';
import { Modal } from '@/components/Modal';
import { useState } from 'react';

interface Props {
  state: StoreState;
  store: StoreApi;
}

export function ReportsPage({ state, store }: Props) {
  const [reportAppId, setReportAppId] = useState<string | null>(null);
  const pendingTasks = state.tasks.filter((t) => !t.completed);

  const reportApp = state.applications.find((a) => a.id === reportAppId);
  const reportText = reportApp
    ? generateReadinessReport(reportApp, state, computeRiskForApp(reportApp, pendingTasks, state.settings))
    : '';

  const exportComplianceCSV = () => {
    const rows = state.applications.map((a) => {
      const risk = computeRiskForApp(a, pendingTasks, state.settings);
      const missing = missingRequiredDocs(a);
      return {
        ApplicationID: a.id,
        Institution: a.institutionName,
        Type: a.applicationType,
        Status: a.status,
        Deadline: formatDate(a.deadline),
        DaysLeft: daysToDeadline(a),
        RiskLevel: risk.level,
        RiskScore: risk.score,
        MissingRequiredDocs: missing.length,
        MissingItems: missing.map((m) => m.type).join('; '),
      };
    });
    downloadFile('AICTEFlow_compliance_report.csv', toCSV(rows), 'text/csv');
  };

  const exportAuditCSV = () => {
    const rows = state.audit.map((e) => ({
      Timestamp: e.timestamp,
      Actor: e.actor,
      Action: e.action,
      ApplicationID: e.applicationId ?? '',
      Details: e.details ?? '',
    }));
    downloadFile('AICTEFlow_audit_trail.csv', toCSV(rows), 'text/csv');
  };

  const exportTasksCSV = () => {
    const rows = state.tasks.map((t) => {
      const u = state.users.find((x) => x.id === t.assigneeId);
      return {
        TaskID: t.id,
        Title: t.title,
        ApplicationID: t.applicationId ?? '',
        Assignee: u?.name ?? '',
        Role: u?.role ?? '',
        Priority: t.priority,
        DueDate: formatDate(t.dueDate),
        Completed: t.completed ? 'Yes' : 'No',
      };
    });
    downloadFile('AICTEFlow_tasks.csv', toCSV(rows), 'text/csv');
  };

  return (
    <PageContainer>
      <SectionTitle title="Reports" subtitle="Generate and export compliance summaries" />

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
        <div className="card p-5">
          <div className="flex items-center gap-2 mb-2"><FileText className="h-5 w-5 text-blue-600" /><h3 className="font-semibold text-slate-900">Application Summary (CSV)</h3></div>
          <p className="text-sm text-slate-500 mb-3">Export all applications with status, deadline, progress, and missing-document counts.</p>
          <button onClick={() => downloadFile('AICTEFlow_applications.csv', generateApplicationSummaryCSV(state), 'text/csv')} className="btn-primary"><Download className="h-4 w-4" /> Export CSV</button>
        </div>

        <div className="card p-5">
          <div className="flex items-center gap-2 mb-2"><ShieldCheck className="h-5 w-5 text-emerald-600" /><h3 className="font-semibold text-slate-900">Compliance Report (CSV)</h3></div>
          <p className="text-sm text-slate-500 mb-3">Risk levels, missing documents, and contributing factors per application.</p>
          <button onClick={exportComplianceCSV} className="btn-primary"><Download className="h-4 w-4" /> Export CSV</button>
        </div>

        <div className="card p-5">
          <div className="flex items-center gap-2 mb-2"><FileText className="h-5 w-5 text-amber-600" /><h3 className="font-semibold text-slate-900">Tasks Report (CSV)</h3></div>
          <p className="text-sm text-slate-500 mb-3">All tasks with assignees, roles, priority, and completion status.</p>
          <button onClick={exportTasksCSV} className="btn-primary"><Download className="h-4 w-4" /> Export CSV</button>
        </div>

        <div className="card p-5">
          <div className="flex items-center gap-2 mb-2"><FileText className="h-5 w-5 text-slate-600" /><h3 className="font-semibold text-slate-900">Audit Trail (CSV)</h3></div>
          <p className="text-sm text-slate-500 mb-3">All recorded actions with timestamps, actors, and related applications.</p>
          <button onClick={exportAuditCSV} className="btn-primary"><Download className="h-4 w-4" /> Export CSV</button>
        </div>
      </div>

      <div className="card p-4">
        <SectionTitle title="One-Click Readiness Reports" subtitle="Per-application consolidated summary (printable / downloadable)" />
        {state.applications.length === 0 ? (
          <p className="text-sm text-slate-500 text-center py-6">No applications.</p>
        ) : (
          <div className="space-y-2">
            {state.applications.map((a) => {
              const risk = computeRiskForApp(a, pendingTasks, state.settings);
              const missing = missingRequiredDocs(a).length;
              return (
                <div key={a.id} className="flex items-center gap-3 p-3 rounded-lg border border-slate-200">
                  <div className="flex-1 min-w-0">
                    <p className="font-medium text-sm text-slate-900 truncate">{a.institutionName}</p>
                    <div className="flex items-center gap-2 mt-1 flex-wrap">
                      <span className="text-xs text-slate-500">{a.id}</span>
                      <StatusBadge status={a.status} />
                      <RiskBadge level={risk.level} score={risk.score} />
                      {missing > 0 && <span className="text-xs text-red-600">{missing} missing</span>}
                    </div>
                  </div>
                  <button onClick={() => setReportAppId(a.id)} className="btn-secondary text-xs"><Printer className="h-3.5 w-3.5" /> Generate</button>
                </div>
              );
            })}
          </div>
        )}
        <p className="text-xs text-slate-400 mt-3">Reports clearly separate system checks from authorized human verification. These are prototype summaries, not official AICTE documents.</p>
      </div>

      <Modal open={!!reportAppId} onClose={() => setReportAppId(null)} title="Application Readiness Report" size="lg"
        footer={<>
          <button onClick={() => window.print()} className="btn-secondary"><Printer className="h-4 w-4" /> Print</button>
          <button onClick={() => reportApp && downloadFile(`${reportApp.id}_readiness_report.txt`, reportText, 'text/plain')} className="btn-primary"><Download className="h-4 w-4" /> Download</button>
          <button onClick={() => setReportAppId(null)} className="btn-secondary">Close</button>
        </>}
      >
        <pre className="text-xs text-slate-700 whitespace-pre-wrap bg-slate-50 rounded-lg p-4 border border-slate-200 font-mono leading-relaxed">{reportText}</pre>
      </Modal>
    </PageContainer>
  );
}
