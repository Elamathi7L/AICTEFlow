import { useMemo, useState } from 'react';
import { Plus, CheckCircle2, Circle, AlertTriangle, Calendar, Bell } from 'lucide-react';
import type { StoreState, ComplianceTask, Priority } from '@/types';
import type { StoreApi } from '@/store/useStore';
import { PageContainer, SectionTitle, EmptyState, StatCard } from '@/components/Common';
import { PriorityBadge, Avatar } from '@/components/Badges';
import { Modal } from '@/components/Modal';
import { useToast } from '@/components/Toast';
import { formatDate, relativeDays, daysUntil, classNames } from '@/lib/utils';

interface Props {
  state: StoreState;
  store: StoreApi;
  onOpenApp: (id: string) => void;
}

export function CalendarPage({ state, store, onOpenApp }: Props) {
  const { toast } = useToast();
  const [showAdd, setShowAdd] = useState(false);
  const [tab, setTab] = useState<'tasks' | 'notifications'>('tasks');

  const items = useMemo(() => {
    const taskItems = state.tasks.map((t) => ({
      id: t.id,
      kind: 'task' as const,
      date: t.dueDate,
      title: t.title,
      completed: t.completed,
      priority: t.priority,
      applicationId: t.applicationId,
      assigneeId: t.assigneeId,
      data: t,
    }));
    const deadlineItems = state.applications
      .filter((a) => a.status !== 'Approved' && a.status !== 'Rejected')
      .map((a) => ({
        id: `dl-${a.id}`,
        kind: 'deadline' as const,
        date: a.deadline,
        title: `Deadline: ${a.institutionName}`,
        completed: false,
        priority: 'High' as Priority,
        applicationId: a.id,
        assigneeId: undefined,
        data: a,
      }));
    return [...taskItems, ...deadlineItems].sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
  }, [state.tasks, state.applications]);

  const overdue = items.filter((i) => !i.completed && new Date(i.date).getTime() < Date.now() && i.kind === 'task');
  const upcoming = items.filter((i) => !i.completed && daysUntil(i.date) >= 0 && daysUntil(i.date) <= state.settings.reminderLeadDays);

  const toggle = (taskId: string) => {
    store.toggleTaskComplete(taskId);
    const t = state.tasks.find((x) => x.id === taskId);
    store.addAudit('Current User', t && !t.completed ? `Task completed: ${t.title}` : `Task reopened: ${t?.title}`, t?.applicationId);
  };

  return (
    <PageContainer>
      <SectionTitle title="Compliance Calendar" subtitle="Deadlines, tasks, and reminders"
        action={<button onClick={() => setShowAdd(true)} className="btn-primary"><Plus className="h-4 w-4" /> Add Task</button>}
      />

      <div className="grid grid-cols-2 lg:grid-cols-3 gap-3 mb-4">
        <StatCard label="Overdue Tasks" value={overdue.length} icon={AlertTriangle} tone="red" />
        <StatCard label="Due Soon (≤ reminder lead)" value={upcoming.filter((u) => u.kind === 'task').length} icon={Calendar} tone="amber" hint={`${state.settings.reminderLeadDays} day lead`} />
        <StatCard label="Pending Deadlines" value={items.filter((i) => i.kind === 'deadline' && !i.completed).length} icon={Bell} tone="blue" />
      </div>

      <div className="flex gap-1 mb-3">
        <button onClick={() => setTab('tasks')} className={classNames('text-sm px-4 py-2 rounded-lg font-medium', tab === 'tasks' ? 'bg-blue-600 text-white' : 'bg-white border border-slate-200 text-slate-600')}>Calendar & Tasks</button>
        <button onClick={() => setTab('notifications')} className={classNames('text-sm px-4 py-2 rounded-lg font-medium', tab === 'notifications' ? 'bg-blue-600 text-white' : 'bg-white border border-slate-200 text-slate-600')}>Notification History</button>
      </div>

      {tab === 'tasks' ? (
        items.length === 0 ? (
          <EmptyState title="Nothing scheduled" description="Add a task to start tracking deadlines." />
        ) : (
          <div className="space-y-2">
            {items.map((i) => {
              const days = daysUntil(i.date);
              const isOverdue = !i.completed && days < 0 && i.kind === 'task';
              const isSoon = !i.completed && days >= 0 && days <= state.settings.reminderLeadDays;
              return (
                <div key={i.id} className={`card p-3.5 flex items-center gap-3 ${isOverdue ? 'border-red-300 bg-red-50/30' : isSoon ? 'border-amber-300 bg-amber-50/30' : ''}`}>
                  {i.kind === 'task' ? (
                    <button onClick={() => toggle(i.id)} className="flex-shrink-0">
                      {i.completed ? <CheckCircle2 className="h-5 w-5 text-emerald-500" /> : <Circle className="h-5 w-5 text-slate-300 hover:text-blue-500" />}
                    </button>
                  ) : (
                    <Calendar className="h-5 w-5 text-blue-500 flex-shrink-0" />
                  )}
                  <div className="flex-1 min-w-0">
                    <p className={`text-sm font-medium ${i.completed ? 'line-through text-slate-400' : 'text-slate-800'}`}>{i.title}</p>
                    <div className="flex items-center gap-2 mt-0.5 flex-wrap">
                      <span className={`text-xs ${isOverdue ? 'text-red-600 font-medium' : isSoon ? 'text-amber-600 font-medium' : 'text-slate-500'}`}>
                        {formatDate(i.date)} · {relativeDays(i.date)}
                      </span>
                      {i.kind === 'task' && <PriorityBadge priority={i.priority} />}
                      {i.applicationId && <button onClick={() => onOpenApp(i.applicationId!)} className="text-xs text-blue-600 hover:underline">{i.applicationId}</button>}
                    </div>
                  </div>
                  {i.kind === 'deadline' && (
                    <span className="text-[10px] font-semibold uppercase text-blue-600 bg-blue-50 px-2 py-0.5 rounded">Deadline</span>
                  )}
                  {i.assigneeId && (() => {
                    const u = state.users.find((x) => x.id === i.assigneeId);
                    return u ? <Avatar name={u.name} size="sm" /> : null;
                  })()}
                </div>
              );
            })}
          </div>
        )
      ) : (
        <div className="card p-4">
          <h3 className="text-sm font-semibold text-slate-700 mb-3">Notification History</h3>
          {state.notifications.length === 0 ? (
            <p className="text-sm text-slate-500 text-center py-6">No notifications.</p>
          ) : (
            <div className="space-y-2">
              {state.notifications.map((n) => (
                <div key={n.id} className="flex items-start gap-2.5 p-2.5 rounded-lg bg-slate-50">
                  <Bell className="h-4 w-4 text-blue-500 mt-0.5 flex-shrink-0" />
                  <div className="flex-1">
                    <p className="text-sm text-slate-800">{n.message}</p>
                    <p className="text-xs text-slate-500 mt-0.5">{formatDate(n.date)} · {relativeDays(n.date)}{n.applicationId ? ` · ${n.applicationId}` : ''}</p>
                  </div>
                </div>
              ))}
            </div>
          )}
          <p className="text-xs text-slate-400 mt-3">Demo notifications — no real email or SMS is sent. Configure a provider to enable real delivery.</p>
        </div>
      )}

      <AddTaskModalFull open={showAdd} onClose={() => setShowAdd(false)} store={store} state={state} onToast={toast} />
    </PageContainer>
  );
}

function AddTaskModalFull({ open, onClose, store, state, onToast }: { open: boolean; onClose: () => void; store: StoreApi; state: StoreState; onToast: (m: string, t?: 'success' | 'error' | 'info') => void }) {
  const [title, setTitle] = useState('');
  const [appId, setAppId] = useState(state.applications[0]?.id ?? '');
  const [due, setDue] = useState(() => { const d = new Date(); d.setDate(d.getDate() + 7); return d.toISOString().slice(0, 10); });
  const [priority, setPriority] = useState<Priority>('Medium');
  const [assignee, setAssignee] = useState(state.users[0]?.id ?? '');

  const submit = () => {
    if (!title.trim()) { onToast('Title is required', 'error'); return; }
    const task: ComplianceTask = {
      id: `task-${Date.now()}`,
      title: title.trim(),
      applicationId: appId || undefined,
      assigneeId: assignee || undefined,
      dueDate: new Date(due + 'T23:59:59').toISOString(),
      priority,
      completed: false,
      createdAt: new Date().toISOString(),
    };
    store.addTask(task);
    store.addAudit('Current User', `Task created: ${task.title}`, appId || undefined);
    store.addNotification({ id: `n-${Date.now()}`, date: new Date().toISOString(), applicationId: appId || undefined, message: `New task: ${task.title}` });
    onToast('Task added', 'success');
    setTitle('');
    onClose();
  };

  return (
    <Modal open={open} onClose={onClose} title="Add Compliance Task" size="sm"
      footer={<><button onClick={onClose} className="btn-secondary">Cancel</button><button onClick={submit} className="btn-primary">Add Task</button></>}
    >
      <div className="space-y-3">
        <div><label className="label">Title</label><input value={title} onChange={(e) => setTitle(e.target.value)} className="input" placeholder="e.g. Upload NOC document" /></div>
        <div><label className="label">Application (optional)</label><select value={appId} onChange={(e) => setAppId(e.target.value)} className="input"><option value="">— None —</option>{state.applications.map((a) => <option key={a.id} value={a.id}>{a.id} · {a.institutionName}</option>)}</select></div>
        <div className="grid grid-cols-2 gap-3">
          <div><label className="label">Due Date</label><input type="date" value={due} onChange={(e) => setDue(e.target.value)} className="input" /></div>
          <div><label className="label">Priority</label><select value={priority} onChange={(e) => setPriority(e.target.value as Priority)} className="input"><option>Low</option><option>Medium</option><option>High</option></select></div>
        </div>
        <div><label className="label">Assignee</label><select value={assignee} onChange={(e) => setAssignee(e.target.value)} className="input"><option value="">— Unassigned —</option>{state.users.map((u) => <option key={u.id} value={u.id}>{u.name} ({u.role})</option>)}</select></div>
      </div>
    </Modal>
  );
}
