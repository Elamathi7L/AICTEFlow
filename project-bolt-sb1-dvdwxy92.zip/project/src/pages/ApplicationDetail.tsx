import { useMemo, useState } from 'react';
import {
  ArrowLeft,
  Upload,
  FileCheck2,
  FileX2,
  AlertTriangle,
  Bot,
  Printer,
  Download,
  Plus,
  History as HistoryIcon,
  ShieldCheck,
} from 'lucide-react';
import type { StoreApi } from '@/store/useStore';
import type { StoreState, WorkflowApp, AppStatus, DocumentStatus } from '@/types';
import { PageContainer, SectionTitle, EmptyState } from '@/components/Common';
import { StatusBadge, DocStatusBadge, RiskBadge, ProgressBar, Avatar } from '@/components/Badges';
import { Modal } from '@/components/Modal';
import { useToast } from '@/components/Toast';
import { computeRiskForApp } from '@/lib/risk';
import { missingRequiredDocs, isDocumentReady, daysToDeadline } from '@/store/useStore';
import { answerAssistant, SUGGESTED_QUESTIONS } from '@/lib/assistant';
import { formatDate, formatDateTime, relativeDays, downloadFile } from '@/lib/utils';
import { generateReadinessReport } from '@/lib/report';

interface Props {
  appId: string;
  store: StoreApi;
  onBack: () => void;
  onNavigate: (page: 'documents' | 'calendar') => void;
}

const STATUSES: AppStatus[] = ['Draft', 'Submitted', 'Under Review', 'Correction Required', 'Approved', 'Rejected'];

export function ApplicationDetail({ appId, store, onBack, onNavigate }: Props) {
  const { state } = store;
  const { toast } = useToast();
  const app = state.applications.find((a) => a.id === appId);
  const [showUpload, setShowUpload] = useState<string | null>(null);
  const [showTask, setShowTask] = useState(false);
  const [selectedQ, setSelectedQ] = useState(0);
  const [showReport, setShowReport] = useState(false);

  const pendingTasks = state.tasks.filter((t) => !t.completed);
  const risk = useMemo(
    () => (app ? computeRiskForApp(app, pendingTasks, state.settings) : null),
    [app, pendingTasks, state.settings],
  );

  if (!app) {
    return (
      <PageContainer>
        <EmptyState title="Application not found" description="It may have been deleted." action={<button onClick={onBack} className="btn-primary">Back to applications</button>} />
      </PageContainer>
    );
  }

  const missing = missingRequiredDocs(app);
  const ready = isDocumentReady(app);
  const days = daysToDeadline(app);
  const appTasks = state.tasks.filter((t) => t.applicationId === app.id);
  const reply = answerAssistant(SUGGESTED_QUESTIONS[selectedQ], state, app);

  const changeStatus = (status: AppStatus) => {
    if (status === 'Submitted' && !ready) {
      toast('Cannot mark document-ready: required documents are still missing.', 'error');
      return;
    }
    store.changeAppStatus(app.id, status, `Status changed to ${status}`);
    store.addAudit('Current User', `Status changed to ${status}`, app.id);
    store.addAlert({
      id: `alert-${Date.now()}`,
      severity: status === 'Approved' ? 'info' : status === 'Rejected' ? 'critical' : status === 'Correction Required' ? 'warning' : 'info',
      date: new Date().toISOString(),
      applicationId: app.id,
      message: `${app.institutionName} (${app.id}) moved to ${status}.`,
      recommendedAction: status === 'Correction Required' ? 'Address reviewer notes and resubmit.' : 'Review updated status.',
      read: false,
      resolved: false,
    });
    toast(`Status updated to ${status}`, 'success');
  };

  const handleUpload = (filename: string) => {
    if (!showUpload) return;
    store.uploadDocument(app.id, showUpload, filename, 'Current User');
    const doc = app.documents.find((d) => d.id === showUpload);
    store.addAudit('Current User', `Document ${filename} uploaded`, app.id, doc?.type);
    toast('Document uploaded', 'success');
    setShowUpload(null);
  };

  const setDocStatus = (docId: string, status: DocumentStatus) => {
    store.setDocumentStatus(app.id, docId, status, 'Current User');
    const doc = app.documents.find((d) => d.id === docId);
    store.addAudit('Current User', `Document "${doc?.type}" marked ${status}`, app.id);
    toast(`Marked as ${status}`, 'success');
  };

  const report = generateReadinessReport(app, state, risk!);

  return (
    <PageContainer>
      <button onClick={onBack} className="btn-ghost mb-4 -ml-2">
        <ArrowLeft className="h-4 w-4" /> Back to applications
      </button>

      <div className="card p-5 mb-4">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <h2 className="text-xl font-bold text-slate-900">{app.institutionName}</h2>
              <StatusBadge status={app.status} />
              {risk && <RiskBadge level={risk.level} score={risk.score} />}
            </div>
            <p className="text-sm text-slate-500 mt-1">{app.id} · {app.applicationType} · Created {formatDate(app.createdAt)}</p>
            <p className="text-sm mt-1">
              <span className="text-slate-500">Deadline:</span>{' '}
              <span className={days < 0 ? 'text-red-600 font-medium' : days <= 7 ? 'text-amber-600 font-medium' : 'text-slate-700 font-medium'}>
                {formatDate(app.deadline)} ({relativeDays(app.deadline)})
              </span>
            </p>
          </div>
          <div className="flex flex-wrap gap-2">
            <button onClick={() => setShowReport(true)} className="btn-secondary"><Printer className="h-4 w-4" /> Readiness Report</button>
            <button onClick={() => setShowTask(true)} className="btn-secondary"><Plus className="h-4 w-4" /> Add Task</button>
          </div>
        </div>
        <div className="mt-4">
          <div className="flex items-center justify-between text-xs text-slate-500 mb-1">
            <span>Progress</span><span>{app.progress}%</span>
          </div>
          <ProgressBar value={app.progress} />
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 mb-4">
        <div className="card p-4 lg:col-span-2">
          <SectionTitle title="Status Workflow" subtitle="Change the application status" />
          <div className="flex flex-wrap gap-2">
            {STATUSES.map((s) => (
              <button
                key={s}
                onClick={() => changeStatus(s)}
                disabled={s === app.status}
                className={`px-3 py-1.5 rounded-lg text-xs font-medium border transition-colors ${
                  s === app.status
                    ? 'bg-blue-600 text-white border-blue-600'
                    : 'bg-white text-slate-700 border-slate-300 hover:bg-slate-50'
                }`}
              >
                {s}
              </button>
            ))}
          </div>
          {missing.length > 0 && (
            <div className="mt-3 flex items-start gap-2 rounded-lg bg-amber-50 border border-amber-200 p-3 text-sm text-amber-800">
              <AlertTriangle className="h-4 w-4 mt-0.5 flex-shrink-0" />
              <span>{missing.length} required document(s) missing — the application cannot be submitted as document-ready. Upload: {missing.map((m) => m.type).join(', ')}.</span>
            </div>
          )}
          <div className="mt-4">
            <h4 className="text-sm font-semibold text-slate-700 mb-2 flex items-center gap-1.5"><HistoryIcon className="h-4 w-4" /> Status History</h4>
            <ol className="space-y-2">
              {[...app.history].reverse().map((h, i) => (
                <li key={i} className="flex items-start gap-3 text-sm">
                  <span className="mt-1.5 h-2 w-2 rounded-full bg-blue-500 flex-shrink-0" />
                  <div>
                    <StatusBadge status={h.status} />
                    <p className="text-xs text-slate-500 mt-0.5">{formatDateTime(h.date)}{h.note ? ` · ${h.note}` : ''}</p>
                  </div>
                </li>
              ))}
            </ol>
          </div>
        </div>

        <div className="card p-4">
          <SectionTitle title="AI Assistant" subtitle="Personalized next steps" />
          <div className="rounded-lg bg-blue-50 border border-blue-100 p-3 mb-3">
            <div className="flex items-center gap-1.5 text-blue-600 mb-1.5">
              <Bot className="h-4 w-4" />
              <span className="text-xs font-semibold uppercase">Simulated</span>
            </div>
            <p className="text-sm text-slate-700 whitespace-pre-line leading-relaxed">{reply.text}</p>
          </div>
          <div className="flex flex-wrap gap-1.5">
            {SUGGESTED_QUESTIONS.map((qq, i) => (
              <button key={qq} onClick={() => setSelectedQ(i)} className={`text-[11px] rounded-full px-2 py-0.5 border ${i === selectedQ ? 'bg-blue-600 text-white border-blue-600' : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-100'}`}>{qq}</button>
            ))}
          </div>
        </div>
      </div>

      <div className="card p-4 mb-4">
        <SectionTitle title="Documents" subtitle="Upload, verify, and track document status" action={<span className="text-xs text-slate-500">{missing.length} missing · {app.documents.filter((d) => d.status === 'Verified').length} verified</span>} />
        {app.documents.length === 0 ? (
          <p className="text-sm text-slate-500 py-4 text-center">No documents in checklist.</p>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-slate-50 text-slate-600 text-xs uppercase">
                <tr>
                  <th className="text-left font-semibold px-3 py-2">Document Type</th>
                  <th className="text-left font-semibold px-3 py-2">Status</th>
                  <th className="text-left font-semibold px-3 py-2 hidden md:table-cell">Filename</th>
                  <th className="text-left font-semibold px-3 py-2 hidden sm:table-cell">Uploaded</th>
                  <th className="text-left font-semibold px-3 py-2">Versions</th>
                  <th className="text-right font-semibold px-3 py-2">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {app.documents.map((d) => {
                  const req = app.checklist.find((c) => c.type === d.type)?.required;
                  return (
                    <tr key={d.id} className="table-row-hover">
                      <td className="px-3 py-2.5">
                        <div className="flex items-center gap-2">
                          {d.status === 'Missing' ? <FileX2 className="h-4 w-4 text-red-500" /> : <FileCheck2 className="h-4 w-4 text-blue-500" />}
                          <div>
                            <p className="font-medium text-slate-800">{d.type}</p>
                            {req && <span className="text-[10px] text-red-500 font-medium">Required</span>}
                            {!req && <span className="text-[10px] text-slate-400">Optional</span>}
                          </div>
                        </div>
                      </td>
                      <td className="px-3 py-2.5"><DocStatusBadge status={d.status} /></td>
                      <td className="px-3 py-2.5 text-slate-600 hidden md:table-cell">{d.filename ?? '—'}</td>
                      <td className="px-3 py-2.5 text-slate-500 hidden sm:table-cell">{d.uploadedAt ? formatDate(d.uploadedAt) : '—'}</td>
                      <td className="px-3 py-2.5 text-slate-600">{d.versions.length ? `v${d.versions[d.versions.length - 1].version} (${d.versions.length})` : '—'}</td>
                      <td className="px-3 py-2.5">
                        <div className="flex items-center justify-end gap-1">
                          <button onClick={() => setShowUpload(d.id)} className="btn-ghost text-xs px-2 py-1"><Upload className="h-3.5 w-3.5" /> Upload</button>
                          {d.status !== 'Missing' && (
                            <select
                              value={d.status}
                              onChange={(e) => setDocStatus(d.id, e.target.value as DocumentStatus)}
                              className="text-xs border border-slate-300 rounded-md px-1.5 py-1 bg-white"
                            >
                              <option value="Uploaded">Uploaded</option>
                              <option value="Needs Review">Needs Review</option>
                              <option value="Verified">Verified</option>
                              <option value="Missing">Missing</option>
                            </select>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
        <p className="text-xs text-slate-400 mt-3">
          Automated status checks do not verify document authenticity. "Verified" means an authorized reviewer marked it — distinct from a system "Uploaded" check.
        </p>
      </div>

      {risk && risk.factors.length > 0 && (
        <div className="card p-4 mb-4">
          <SectionTitle title="Delay Risk Analysis" subtitle="Prototype estimate — not a guarantee" />
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <div>
              <p className="text-sm font-medium text-slate-700 mb-2">Contributing factors:</p>
              <ul className="space-y-2">
                {risk.factors.map((f, i) => (
                  <li key={i} className="flex items-start gap-2 text-sm">
                    <span className="mt-1 h-2 w-2 rounded-full bg-amber-500 flex-shrink-0" />
                    <div>
                      <p className="text-slate-800">{f.label}</p>
                      <p className="text-xs text-slate-500">{f.detail}</p>
                    </div>
                  </li>
                ))}
              </ul>
            </div>
            <div>
              <p className="text-sm font-medium text-slate-700 mb-2">Recommended actions (in order):</p>
              <ul className="space-y-2">
                {risk.recommendedTasks.map((t, i) => (
                  <li key={i} className="flex items-start gap-2 text-sm text-slate-700">
                    <span className="flex-shrink-0 h-5 w-5 rounded-full bg-blue-100 text-blue-700 text-xs font-bold flex items-center justify-center">{i + 1}</span>
                    {t}
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <div className="card p-4">
          <SectionTitle title="Tasks" action={<button onClick={() => setShowTask(true)} className="btn-ghost text-xs"><Plus className="h-3.5 w-3.5" /> Add</button>} />
          {appTasks.length === 0 ? <p className="text-sm text-slate-500 py-4 text-center">No tasks for this application.</p> : (
            <div className="space-y-2">
              {appTasks.map((t) => {
                const assignee = state.users.find((u) => u.id === t.assigneeId);
                return (
                  <div key={t.id} className="flex items-center gap-3 p-2.5 rounded-lg border border-slate-200">
                    <input type="checkbox" checked={t.completed} onChange={() => store.toggleTaskComplete(t.id)} className="h-4 w-4 rounded accent-blue-600" />
                    <div className="flex-1 min-w-0">
                      <p className={`text-sm ${t.completed ? 'line-through text-slate-400' : 'text-slate-800'}`}>{t.title}</p>
                      <p className="text-xs text-slate-500">Due {formatDate(t.dueDate)} ({relativeDays(t.dueDate)}) · {t.priority}</p>
                    </div>
                    {assignee && <Avatar name={assignee.name} size="sm" />}
                  </div>
                );
              })}
            </div>
          )}
        </div>

        <div className="card p-4">
          <SectionTitle title="Document Version History" subtitle="Audit trail of uploads" />
          {app.documents.every((d) => d.versions.length === 0) ? (
            <p className="text-sm text-slate-500 py-4 text-center">No document uploads yet.</p>
          ) : (
            <div className="space-y-3 max-h-72 overflow-y-auto">
              {app.documents.filter((d) => d.versions.length).map((d) => (
                <div key={d.id}>
                  <p className="text-xs font-semibold text-slate-700 mb-1">{d.type}</p>
                  {d.versions.map((v) => (
                    <div key={v.version} className="flex items-center gap-2 text-xs text-slate-600 pl-3 py-0.5">
                      <span className="font-mono text-blue-600">v{v.version}</span>
                      <span>{v.filename}</span>
                      <span className="text-slate-400">· {v.action} · {formatDate(v.uploadedAt)}</span>
                    </div>
                  ))}
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      <UploadModal open={!!showUpload} onClose={() => setShowUpload(null)} onUpload={handleUpload} docType={app.documents.find((d) => d.id === showUpload)?.type ?? ''} />
      <AddTaskModal open={showTask} onClose={() => setShowTask(false)} store={store} defaultAppId={app.id} users={state.users} />
      <ReportModal open={showReport} onClose={() => setShowReport(false)} app={app} report={report} />
    </PageContainer>
  );
}

function UploadModal({ open, onClose, onUpload, docType }: { open: boolean; onClose: () => void; onUpload: (filename: string) => void; docType: string }) {
  const [name, setName] = useState('');
  return (
    <Modal open={open} onClose={onClose} title="Upload Document" size="sm"
      footer={<><button onClick={onClose} className="btn-secondary">Cancel</button><button onClick={() => { if (name.trim()) { onUpload(name.trim()); setName(''); } }} className="btn-primary">Upload</button></>}
    >
      <div className="space-y-3">
        <p className="text-sm text-slate-600">Document: <span className="font-medium">{docType}</span></p>
        <div>
          <label className="label">Filename</label>
          <input value={name} onChange={(e) => setName(e.target.value)} className="input" placeholder="e.g. NOC_2026.pdf" />
        </div>
        <p className="text-xs text-slate-400">Demo upload — no real file is stored. A version entry is recorded in the audit trail.</p>
      </div>
    </Modal>
  );
}

function AddTaskModal({ open, onClose, store, defaultAppId, users }: { open: boolean; onClose: () => void; store: StoreApi; defaultAppId: string; users: StoreState['users'] }) {
  const [title, setTitle] = useState('');
  const [due, setDue] = useState(() => { const d = new Date(); d.setDate(d.getDate() + 7); return d.toISOString().slice(0, 10); });
  const [priority, setPriority] = useState<'Low' | 'Medium' | 'High'>('Medium');
  const [assignee, setAssignee] = useState(users[0]?.id ?? '');

  const submit = () => {
    if (!title.trim()) return;
    store.addTask({
      id: `task-${Date.now()}`,
      title: title.trim(),
      applicationId: defaultAppId,
      assigneeId: assignee || undefined,
      dueDate: new Date(due + 'T23:59:59').toISOString(),
      priority,
      completed: false,
      createdAt: new Date().toISOString(),
    });
    store.addAudit('Current User', `Task created: ${title.trim()}`, defaultAppId);
    store.addNotification({ id: `n-${Date.now()}`, date: new Date().toISOString(), applicationId: defaultAppId, message: `New task: ${title.trim()}` });
    setTitle('');
    onClose();
  };

  return (
    <Modal open={open} onClose={onClose} title="Add Task" size="sm"
      footer={<><button onClick={onClose} className="btn-secondary">Cancel</button><button onClick={submit} className="btn-primary">Add Task</button></>}
    >
      <div className="space-y-3">
        <div><label className="label">Title</label><input value={title} onChange={(e) => setTitle(e.target.value)} className="input" /></div>
        <div className="grid grid-cols-2 gap-3">
          <div><label className="label">Due Date</label><input type="date" value={due} onChange={(e) => setDue(e.target.value)} className="input" /></div>
          <div><label className="label">Priority</label><select value={priority} onChange={(e) => setPriority(e.target.value as 'Low' | 'Medium' | 'High')} className="input"><option>Low</option><option>Medium</option><option>High</option></select></div>
        </div>
        <div><label className="label">Assignee</label><select value={assignee} onChange={(e) => setAssignee(e.target.value)} className="input">{users.map((u) => <option key={u.id} value={u.id}>{u.name} ({u.role})</option>)}</select></div>
      </div>
    </Modal>
  );
}

function ReportModal({ open, onClose, app, report }: { open: boolean; onClose: () => void; app: WorkflowApp; report: string }) {
  return (
    <Modal open={open} onClose={onClose} title="Application Readiness Report" size="lg"
      footer={<>
        <button onClick={() => window.print()} className="btn-secondary"><Printer className="h-4 w-4" /> Print</button>
        <button onClick={() => downloadFile(`${app.id}_readiness_report.txt`, report, 'text/plain')} className="btn-primary"><Download className="h-4 w-4" /> Download</button>
        <button onClick={onClose} className="btn-secondary">Close</button>
      </>}
    >
      <div className="space-y-3">
        <div className="flex items-center gap-2 text-emerald-600"><ShieldCheck className="h-4 w-4" /><span className="text-xs font-semibold">One-Click Readiness Report · Prototype</span></div>
        <pre className="text-xs text-slate-700 whitespace-pre-wrap bg-slate-50 rounded-lg p-4 border border-slate-200 font-mono leading-relaxed">{report}</pre>
        <p className="text-xs text-slate-400">System checks are separate from authorized human verification. This report is a prototype summary, not an official AICTE document.</p>
      </div>
    </Modal>
  );
}
