import type {
  AppUser,
  StoreState,
  WorkflowApp,
  ComplianceTask,
  Alert,
  AuditEntry,
} from '@/types';

const now = new Date();
const iso = (d: Date) => d.toISOString();
const daysFromNow = (n: number) => {
  const d = new Date(now);
  d.setDate(d.getDate() + n);
  return iso(d);
};
const daysAgo = (n: number) => {
  const d = new Date(now);
  d.setDate(d.getDate() - n);
  return iso(d);
};

export const DEFAULT_USERS: AppUser[] = [
  { id: 'u-admin', name: 'Dr. Anitha Rao', role: 'Administrator', email: 'anitha@inst.edu' },
  { id: 'u-staff', name: 'Ramesh Kumar', role: 'Institution Staff', email: 'ramesh@inst.edu' },
  { id: 'u-reviewer', name: 'Dr. Lakshmi V', role: 'Reviewer', email: 'lakshmi@review.org' },
];

const baseChecklist = [
  { type: 'Institution Accreditation Certificate', required: true },
  { type: 'NOC from State Government', required: true },
  { type: 'Land Documents & Ownership Proof', required: true },
  { type: 'Building Plan Approval', required: true },
  { type: 'Faculty Qualification Records', required: true },
  { type: 'Course Curriculum & Syllabus', required: true },
  { type: 'Financial Statement (Last 3 Years)', required: true },
  { type: 'Bank Statement Proof', required: false },
  { type: 'Anti-Ragging Committee Report', required: false },
  { type: 'Grievance Redressal Policy', required: false },
];

const mkApp = (
  id: string,
  institutionName: string,
  applicationType: string,
  status: WorkflowApp['status'],
  submittedOffset: number | undefined,
  deadlineOffset: number,
  progress: number,
  docStatuses: { type: string; status: WorkflowApp['documents'][number]['status']; versions?: number; filename?: string }[],
): WorkflowApp => {
  const documents = baseChecklist.map((c) => {
    const ds = docStatuses.find((x) => x.type === c.type);
    const versions = ds?.versions
      ? Array.from({ length: ds.versions }, (_, i) => ({
          version: i + 1,
          filename: ds.filename ?? `${c.type.replace(/[^a-zA-Z0-9]/g, '_')}_v${i + 1}.pdf`,
          uploadedAt: daysAgo(20 - i * 5),
          action: i === 0 ? 'Initial upload' : 'Replaced with newer version',
        }))
      : [];
    return {
      id: `doc-${id}-${c.type.replace(/[^a-zA-Z0-9]/g, '')}`,
      type: c.type,
      status: ds?.status ?? 'Missing',
      filename: versions[versions.length - 1]?.filename,
      uploadedAt: versions[versions.length - 1]?.uploadedAt,
      versions,
    };
  });

  const history: WorkflowApp['history'] = [
    { status: 'Draft', date: daysAgo(45), note: 'Application started' },
  ];
  if (status !== 'Draft') {
    history.push({ status: 'Submitted', date: daysAgo(submittedOffset ?? 30), note: 'Submitted for review' });
  }
  if (status === 'Under Review' || status === 'Approved' || status === 'Correction Required' || status === 'Rejected') {
    history.push({ status: 'Under Review', date: daysAgo(submittedOffset ? submittedOffset - 3 : 27), note: 'Reviewer opened file' });
  }
  if (status === 'Correction Required') {
    history.push({ status: 'Correction Required', date: daysAgo(5), note: 'Reviewer flagged missing items' });
  }
  if (status === 'Approved') {
    history.push({ status: 'Approved', date: daysAgo(2), note: 'Application approved' });
  }
  if (status === 'Rejected') {
    history.push({ status: 'Rejected', date: daysAgo(2), note: 'Application rejected' });
  }

  return {
    id,
    institutionName,
    applicationType,
    status,
    submittedDate: status !== 'Draft' ? daysAgo(submittedOffset ?? 30) : undefined,
    createdAt: daysAgo(45),
    deadline: daysFromNow(deadlineOffset),
    progress,
    checklist: baseChecklist,
    documents,
    history,
  };
};

export function buildSeedState(): StoreState {
  const applications: WorkflowApp[] = [
    mkApp('APP-2026-001', 'Sunrise College of Engineering', 'New Institute Approval', 'Under Review', 25, 14, 65, [
      { type: 'Institution Accreditation Certificate', status: 'Verified', versions: 1 },
      { type: 'NOC from State Government', status: 'Uploaded', versions: 2, filename: 'NOC_v2.pdf' },
      { type: 'Land Documents & Ownership Proof', status: 'Uploaded', versions: 1 },
      { type: 'Building Plan Approval', status: 'Needs Review', versions: 1 },
      { type: 'Faculty Qualification Records', status: 'Missing' },
      { type: 'Course Curriculum & Syllabus', status: 'Missing' },
      { type: 'Financial Statement (Last 3 Years)', status: 'Missing' },
    ]),
    mkApp('APP-2026-002', 'Greenfield Polytechnic', 'Course Expansion', 'Correction Required', 20, 7, 40, [
      { type: 'Institution Accreditation Certificate', status: 'Uploaded', versions: 1 },
      { type: 'NOC from State Government', status: 'Missing' },
      { type: 'Land Documents & Ownership Proof', status: 'Uploaded', versions: 1 },
      { type: 'Course Curriculum & Syllabus', status: 'Needs Review', versions: 1 },
      { type: 'Faculty Qualification Records', status: 'Missing' },
    ]),
    mkApp('APP-2026-003', 'Lotus Institute of Management', 'Extension of Approval', 'Submitted', 5, 30, 80, [
      { type: 'Institution Accreditation Certificate', status: 'Verified', versions: 1 },
      { type: 'NOC from State Government', status: 'Uploaded', versions: 1 },
      { type: 'Land Documents & Ownership Proof', status: 'Verified', versions: 1 },
      { type: 'Building Plan Approval', status: 'Uploaded', versions: 1 },
      { type: 'Course Curriculum & Syllabus', status: 'Uploaded', versions: 1 },
      { type: 'Financial Statement (Last 3 Years)', status: 'Uploaded', versions: 1 },
      { type: 'Faculty Qualification Records', status: 'Missing' },
    ]),
    mkApp('APP-2026-004', 'Hilltop Technical Institute', 'New Institute Approval', 'Approved', 40, -2, 100, [
      { type: 'Institution Accreditation Certificate', status: 'Verified', versions: 1 },
      { type: 'NOC from State Government', status: 'Verified', versions: 1 },
      { type: 'Land Documents & Ownership Proof', status: 'Verified', versions: 1 },
      { type: 'Building Plan Approval', status: 'Verified', versions: 1 },
      { type: 'Faculty Qualification Records', status: 'Verified', versions: 1 },
      { type: 'Course Curriculum & Syllabus', status: 'Verified', versions: 1 },
      { type: 'Financial Statement (Last 3 Years)', status: 'Verified', versions: 1 },
    ]),
    mkApp('APP-2026-005', 'Riverdale College of Pharmacy', 'Closure of Institute', 'Draft', undefined, 21, 10, [
      { type: 'Institution Accreditation Certificate', status: 'Missing' },
      { type: 'NOC from State Government', status: 'Missing' },
    ]),
    mkApp('APP-2026-006', 'Sterling Institute of Architecture', 'Course Expansion', 'Rejected', 35, -5, 30, [
      { type: 'Institution Accreditation Certificate', status: 'Uploaded', versions: 1 },
      { type: 'Land Documents & Ownership Proof', status: 'Needs Review', versions: 2 },
    ]),
  ];

  const tasks: ComplianceTask[] = [
    {
      id: 'task-1',
      title: 'Upload Faculty Qualification Records for APP-2026-001',
      description: 'Reviewer requested missing faculty records before final approval.',
      applicationId: 'APP-2026-001',
      assigneeId: 'u-staff',
      dueDate: daysFromNow(4),
      priority: 'High',
      completed: false,
      createdAt: daysAgo(3),
    },
    {
      id: 'task-2',
      title: 'Re-upload corrected NOC document for APP-2026-002',
      applicationId: 'APP-2026-002',
      assigneeId: 'u-staff',
      dueDate: daysFromNow(2),
      priority: 'High',
      completed: false,
      createdAt: daysAgo(2),
    },
    {
      id: 'task-3',
      title: 'Verify Building Plan Approval for APP-2026-001',
      applicationId: 'APP-2026-001',
      assigneeId: 'u-reviewer',
      dueDate: daysFromNow(6),
      priority: 'Medium',
      completed: false,
      createdAt: daysAgo(2),
    },
    {
      id: 'task-4',
      title: 'Submit Financial Statements (3 years) for APP-2026-001',
      applicationId: 'APP-2026-001',
      assigneeId: 'u-staff',
      dueDate: daysFromNow(7),
      priority: 'Medium',
      completed: false,
      createdAt: daysAgo(2),
    },
    {
      id: 'task-5',
      title: 'Annual Compliance Audit Report — all institutions',
      assigneeId: 'u-admin',
      dueDate: daysFromNow(10),
      priority: 'Medium',
      completed: false,
      createdAt: daysAgo(10),
    },
    {
      id: 'task-6',
      title: 'Confirm course curriculum alignment for APP-2026-003',
      applicationId: 'APP-2026-003',
      assigneeId: 'u-reviewer',
      dueDate: daysFromNow(12),
      priority: 'Low',
      completed: true,
      completedAt: daysAgo(1),
      createdAt: daysAgo(8),
    },
    {
      id: 'task-7',
      title: 'Review Grievance Redressal Policy update',
      assigneeId: 'u-admin',
      dueDate: daysAgo(3),
      priority: 'Medium',
      completed: false,
      createdAt: daysAgo(15),
    },
  ];

  const alerts: Alert[] = [
    {
      id: 'alert-1',
      severity: 'critical',
      date: daysAgo(1),
      applicationId: 'APP-2026-001',
      message: '3 required documents missing for Sunrise College application.',
      recommendedAction: 'Upload Faculty Qualification Records, Curriculum and Financial Statement.',
      read: false,
      resolved: false,
    },
    {
      id: 'alert-2',
      severity: 'warning',
      date: daysAgo(1),
      applicationId: 'APP-2026-002',
      message: 'Correction required by reviewer — deadline in 7 days.',
      recommendedAction: 'Re-upload NOC and Curriculum, then resubmit.',
      read: false,
      resolved: false,
    },
    {
      id: 'alert-3',
      severity: 'warning',
      date: daysAgo(2),
      message: 'Compliance task overdue: Review Grievance Redressal Policy update.',
      recommendedAction: 'Complete and close the overdue task.',
      read: true,
      resolved: false,
    },
    {
      id: 'alert-4',
      severity: 'info',
      date: daysAgo(2),
      applicationId: 'APP-2026-004',
      message: 'Application approved for Hilltop Technical Institute.',
      recommendedAction: 'Archive the record and notify the institution.',
      read: true,
      resolved: true,
    },
  ];

  const audit: AuditEntry[] = [
    { id: 'a-1', timestamp: daysAgo(2), actor: 'Dr. Lakshmi V', action: 'Application status changed to Approved', applicationId: 'APP-2026-004' },
    { id: 'a-2', timestamp: daysAgo(5), actor: 'Dr. Lakshmi V', action: 'Application status changed to Correction Required', applicationId: 'APP-2026-002', details: 'NOC missing, curriculum needs review' },
    { id: 'a-3', timestamp: daysAgo(3), actor: 'Ramesh Kumar', action: 'Document NOC_v2.pdf uploaded', applicationId: 'APP-2026-001', details: 'Replaced v1' },
    { id: 'a-4', timestamp: daysAgo(1), actor: 'Dr. Anitha Rao', action: 'Task completed: Confirm course curriculum alignment', applicationId: 'APP-2026-003' },
    { id: 'a-5', timestamp: daysAgo(6), actor: 'Ramesh Kumar', action: 'Application submitted', applicationId: 'APP-2026-003' },
    { id: 'a-6', timestamp: daysAgo(2), actor: 'System', action: 'Application APP-2026-006 status changed to Rejected' },
  ];

  const notifications = [
    { id: 'n-1', date: daysAgo(1), applicationId: 'APP-2026-001', message: 'Reminder: 4 days left to upload Faculty Qualification Records.' },
    { id: 'n-2', date: daysAgo(1), applicationId: 'APP-2026-002', message: 'Reminder: 2 days left to re-upload NOC document.' },
    { id: 'n-3', date: daysAgo(2), message: 'Overdue task: Review Grievance Redressal Policy update.' },
  ];

  return {
    applications,
    tasks,
    alerts,
    notifications,
    audit,
    users: DEFAULT_USERS,
    settings: {
      reminderLeadDays: 5,
      highRiskPendingTaskThreshold: 3,
      mediumRiskPendingTaskThreshold: 2,
      highRiskDaysToDeadline: 7,
      mediumRiskDaysToDeadline: 14,
      resetDataKey: 'AICTEFlow-Demo-v1',
    },
  };
}
