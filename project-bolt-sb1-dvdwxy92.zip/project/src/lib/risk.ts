import type { RiskLevel, Settings, WorkflowApp } from '@/types';

export interface RiskFactor {
  label: string;
  detail: string;
  weight: number; // contribution to score
}

export interface RiskResult {
  level: RiskLevel;
  score: number; // 0-100
  factors: RiskFactor[];
  recommendedTasks: string[];
}

export function computeRiskForApp(
  app: WorkflowApp,
  pendingTasks: { applicationId?: string; title: string; priority: string }[],
  settings: Settings,
): RiskResult {
  const factors: RiskFactor[] = [];
  let score = 0;

  const required = app.checklist.filter((c) => c.required);
  const missing = app.documents.filter(
    (d) => required.find((c) => c.type === d.type) && d.status === 'Missing',
  );
  const needsReview = app.documents.filter((d) => d.status === 'Needs Review');

  if (missing.length > 0) {
    const w = Math.min(30, missing.length * 8);
    factors.push({ label: `${missing.length} required document(s) missing`, detail: missing.map((m) => m.type).join(', '), weight: w });
    score += w;
  }
  if (needsReview.length > 0) {
    const w = Math.min(15, needsReview.length * 5);
    factors.push({ label: `${needsReview.length} document(s) need review`, detail: needsReview.map((m) => m.type).join(', '), weight: w });
    score += w;
  }

  const daysLeft = Math.ceil((new Date(app.deadline).getTime() - Date.now()) / 86400000);
  if (daysLeft < 0) {
    factors.push({ label: 'Deadline passed', detail: `Was due ${Math.abs(daysLeft)} day(s) ago`, weight: 25 });
    score += 25;
  } else if (daysLeft <= settings.highRiskDaysToDeadline) {
    factors.push({ label: 'Deadline very close', detail: `${daysLeft} day(s) remaining`, weight: 20 });
    score += 20;
  } else if (daysLeft <= settings.mediumRiskDaysToDeadline) {
    factors.push({ label: 'Deadline approaching', detail: `${daysLeft} day(s) remaining`, weight: 10 });
    score += 10;
  }

  const appTasks = pendingTasks.filter((t) => t.applicationId === app.id);
  if (appTasks.length >= settings.highRiskPendingTaskThreshold) {
    factors.push({ label: `${appTasks.length} pending task(s)`, detail: appTasks.map((t) => t.title).join('; '), weight: 18 });
    score += 18;
  } else if (appTasks.length >= settings.mediumRiskPendingTaskThreshold) {
    factors.push({ label: `${appTasks.length} pending task(s)`, detail: appTasks.map((t) => t.title).join('; '), weight: 10 });
    score += 10;
  } else if (appTasks.length > 0) {
    factors.push({ label: `${appTasks.length} pending task(s)`, detail: appTasks.map((t) => t.title).join('; '), weight: 4 });
    score += 4;
  }

  if (app.status === 'Correction Required') {
    factors.push({ label: 'Reviewer requested corrections', detail: 'Status: Correction Required', weight: 12 });
    score += 12;
  }
  if (app.status === 'Rejected') {
    factors.push({ label: 'Application rejected', detail: 'Status: Rejected', weight: 8 });
    score += 8;
  }

  const daysInStatus = (() => {
    const last = app.history[app.history.length - 1];
    if (!last) return 0;
    return Math.ceil((Date.now() - new Date(last.date).getTime()) / 86400000);
  })();
  if ((app.status === 'Under Review' || app.status === 'Submitted') && daysInStatus > 14) {
    factors.push({ label: `In "${app.status}" for ${daysInStatus} day(s)`, detail: 'Long time in current status', weight: 8 });
    score += 8;
  }

  score = Math.min(100, score);

  let level: RiskLevel = 'Low';
  if (score >= 45) level = 'High';
  else if (score >= 20) level = 'Medium';

  const recommendedTasks: string[] = [];
  if (missing.length > 0) recommendedTasks.push(`Upload missing required documents (${missing.length})`);
  if (appTasks.length > 0) {
    const high = appTasks.filter((t) => t.priority === 'High');
    if (high.length > 0) recommendedTasks.push(`Complete high-priority tasks: ${high.map((t) => t.title).join('; ')}`);
    else recommendedTasks.push(`Complete pending tasks (${appTasks.length})`);
  }
  if (needsReview.length > 0) recommendedTasks.push(`Have reviewer verify: ${needsReview.map((d) => d.type).join(', ')}`);
  if (daysLeft <= settings.mediumRiskDaysToDeadline && daysLeft >= 0) recommendedTasks.push(`Prioritize deadline — ${daysLeft} day(s) left`);
  if (app.status === 'Correction Required') recommendedTasks.push('Address reviewer corrections and resubmit');
  if (app.status === 'Draft') recommendedTasks.push('Complete checklist and submit the application');

  return { level, score, factors, recommendedTasks };
}
