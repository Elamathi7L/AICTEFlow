import type { StoreState, WorkflowApp } from '@/types';
import { computeRiskForApp } from '@/lib/risk';
import { daysToDeadline, missingRequiredDocs } from '@/store/useStore';

export interface AssistantReply {
  text: string;
  relatedAppId?: string;
  suggestedQuestions?: string[];
}

interface Intent {
  id: string;
  match: (q: string) => boolean;
  respond: (ctx: AssistantContext) => AssistantReply;
}

interface AssistantContext {
  query: string;
  state: StoreState;
  selectedApp?: WorkflowApp;
  isTanglish: boolean;
}

const tanglishMarkers = [
  'enna', 'epdi', 'eppadi', 'panna', 'panrathu', 'seiyam', 'seiya',
  'next enna', 'enna seiya', 'thervu', 'theervu', 'puriyala', 'puriyala',
  'kaetu', 'ketu', 'apporam', 'appuram', 'innum', 'ippo',
];

export function isTanglish(query: string): boolean {
  const q = query.toLowerCase();
  return tanglishMarkers.some((m) => q.includes(m));
}

function appSummary(app: WorkflowApp): string {
  const missing = missingRequiredDocs(app);
  const days = daysToDeadline(app);
  return `${app.institutionName} (${app.id}) — status: ${app.status}. ${missing.length} required document(s) missing. Deadline in ${days} day(s).`;
}

const tanglishIntro = (s: string) => `Adaengappa! ${s}`;

const intents: Intent[] = [
  {
    id: 'what-next',
    match: (q) => /what.*(should|do).*next|next.*(step|action)|panra|panna|next enna|enna seiya|what now/i.test(q),
    respond: (ctx) => {
      const app = ctx.selectedApp ?? pickUrgentApp(ctx.state);
      if (!app) {
        return {
          text: ctx.isTanglish
            ? 'Oru application select pannunga, appram than next steps solla mudiyum. Innum applications illa.'
            : 'No applications available to recommend next steps for.',
          suggestedQuestions: SUGGESTED_QUESTIONS,
        };
      }
      const risk = computeRiskForApp(app, ctx.state.tasks, ctx.state.settings);
      const missing = missingRequiredDocs(app);
      const parts: string[] = [];
      if (ctx.isTanglish) {
        parts.push(`${app.institutionName} (${app.id}) ku next steps:`);
        if (missing.length) parts.push(`1) Missing documents upload pannunga: ${missing.map((m) => m.type).join(', ')}.`);
        const highTasks = ctx.state.tasks.filter((t) => t.applicationId === app.id && !t.completed && t.priority === 'High');
        if (highTasks.length) parts.push(`2) High priority tasks mudinga: ${highTasks.map((t) => t.title).join('; ')}.`);
        if (app.status === 'Draft') parts.push(`3) Checklist complete pannitu submit pannunga.`);
        if (risk.level === 'High') parts.push(`Warning: Delay risk high — ippo act pannunga! (Prototype estimate)`);
      } else {
        parts.push(`For ${app.institutionName} (${app.id}), here are the recommended next steps:`);
        if (missing.length) parts.push(`1) Upload the missing required documents: ${missing.map((m) => m.type).join(', ')}.`);
        const highTasks = ctx.state.tasks.filter((t) => t.applicationId === app.id && !t.completed && t.priority === 'High');
        if (highTasks.length) parts.push(`2) Complete the high-priority tasks: ${highTasks.map((t) => t.title).join('; ')}.`);
        if (app.status === 'Draft') parts.push(`3) Finish the checklist and submit the application.`);
        if (risk.level === 'High') parts.push(`Heads up: this application has high delay risk — act now. (Prototype estimate, not a guarantee.)`);
      }
      return { text: parts.join('\n'), relatedAppId: app.id, suggestedQuestions: SUGGESTED_QUESTIONS };
    },
  },
  {
    id: 'missing-docs',
    match: (q) => /missing.*(doc|file)|which.*document|what.*missing|enna.*missing|documents.*missing|file.*illai|illa/i.test(q),
    respond: (ctx) => {
      const app = ctx.selectedApp ?? pickUrgentApp(ctx.state);
      if (!app) return { text: ctx.isTanglish ? 'Innum applications illa.' : 'No applications found.' };
      const missing = missingRequiredDocs(app);
      if (missing.length === 0) {
        return { text: ctx.isTanglish ? `${app.institutionName} ku onnu missing illa. All required documents uploaded.` : `No required documents are missing for ${app.institutionName}.`, relatedAppId: app.id };
      }
      const list = missing.map((m) => `• ${m.type}`).join('\n');
      return {
        text: ctx.isTanglish
          ? `${app.institutionName} (${app.id}) ku missing documents:\n${list}\nIdhai upload pannunga. (System check — authenticity verify pannathu reviewer pannuvaar.)`
          : `Missing required documents for ${app.institutionName} (${app.id}):\n${list}\nUpload these to proceed. (Automated check — a reviewer must still verify authenticity.)`,
        relatedAppId: app.id,
      };
    },
  },
  {
    id: 'why-delay-risk',
    match: (q) => /why.*risk|delay.*risk|risk.*high|risk.*why|risk.*enna|risk pathi|risk.*high.*ah/i.test(q),
    respond: (ctx) => {
      const app = ctx.selectedApp ?? pickUrgentApp(ctx.state);
      if (!app) return { text: ctx.isTanglish ? 'Applications illa.' : 'No applications found.' };
      const risk = computeRiskForApp(app, ctx.state.tasks, ctx.state.settings);
      const factors = risk.factors.map((f) => `• ${f.label}`).join('\n');
      return {
        text: ctx.isTanglish
          ? `${app.institutionName} (${app.id}) delay risk: ${risk.level} (score ${risk.score}/100).\nReasons:\n${factors}\nRecommended: ${risk.recommendedTasks.join('; ')}.\n(Idhu prototype estimate, confirmed prediction illa.)`
          : `${app.institutionName} (${app.id}) has ${risk.level} delay risk (score ${risk.score}/100).\nContributing factors:\n${factors}\nRecommended actions: ${risk.recommendedTasks.join('; ')}.\n(This is a prototype estimate, not a confirmed prediction.)`,
        relatedAppId: app.id,
      };
    },
  },
  {
    id: 'deadlines',
    match: (q) => /deadline|due date|approaching|kaetkira|deadline.*enna|date/i.test(q),
    respond: (ctx) => {
      const upcoming = ctx.state.applications
        .map((a) => ({ a, days: daysToDeadline(a) }))
        .filter((x) => x.days >= 0)
        .sort((x, y) => x.days - y.days);
      if (upcoming.length === 0) return { text: ctx.isTanglish ? 'Innum upcoming deadlines illa.' : 'No upcoming deadlines.' };
      const lines = upcoming.slice(0, 5).map((x) => `• ${x.a.institutionName} (${x.a.id}) — ${x.days} day(s) left, status ${x.a.status}`);
      return {
        text: ctx.isTanglish
          ? `Approaching deadlines:\n${lines.join('\n')}\n(Prototype reminder — real email/SMS illa.)`
          : `Upcoming deadlines:\n${lines.join('\n')}\n(Prototype reminder — no real email or SMS is sent.)`,
      };
    },
  },
  {
    id: 'pending-tasks',
    match: (q) => /pending.*task|task.*(complete|finish)|how.*complete|tasks.*enna|mudinga|mudingala|complete.*task/i.test(q),
    respond: (ctx) => {
      const pending = ctx.state.tasks.filter((t) => !t.completed).sort(taskPrioritySort);
      if (pending.length === 0) return { text: ctx.isTanglish ? 'All tasks complete!' : 'All tasks are complete.' };
      const lines = pending.slice(0, 6).map((t) => {
        const days = Math.ceil((new Date(t.dueDate).getTime() - Date.now()) / 86400000);
        return `• [${t.priority}] ${t.title} — due in ${days}d${t.applicationId ? ` (${t.applicationId})` : ''}`;
      });
      return {
        text: ctx.isTanglish
          ? `Pending tasks (priority order):\n${lines.join('\n')}\nHigh priority tasks mudinga first.`
          : `Pending tasks (priority order):\n${lines.join('\n')}\nComplete high-priority tasks first.`,
      };
    },
  },
  {
    id: 'app-status',
    match: (q) => /status|application.*where|where.*application|thervu|theervu|en.*status/i.test(q),
    respond: (ctx) => {
      const app = ctx.selectedApp ?? ctx.state.applications[0];
      if (!app) return { text: ctx.isTanglish ? 'Applications illa.' : 'No applications.' };
      return { text: ctx.isTanglish ? appSummary(app) + ' (Prototype status.)' : appSummary(app) + ' (Prototype status.)', relatedAppId: app.id };
    },
  },
  {
    id: 'compliance-checklist',
    match: (q) => /checklist|compliance.*what|what.*compliance|requirements|thevai|thevaiyana/i.test(q),
    respond: (ctx) => {
      const app = ctx.selectedApp ?? ctx.state.applications[0];
      if (!app) return { text: ctx.isTanglish ? 'Applications illa.' : 'No applications.' };
      const req = app.checklist.filter((c) => c.required).map((c) => {
        const d = app.documents.find((x) => x.type === c.type);
        return `• ${c.type} — ${d?.status ?? 'Missing'}`;
      });
      return {
        text: ctx.isTanglish
          ? `Compliance checklist for ${app.institutionName}:\n${req.join('\n')}\n(Idhu demo checklist, official AICTE rules illa.)`
          : `Compliance checklist for ${app.institutionName}:\n${req.join('\n')}\n(This is a demo checklist, not the official AICTE requirement list.)`,
        relatedAppId: app.id,
      };
    },
  },
  {
    id: 'greeting',
    match: (q) => /^(hi|hello|hey|vanakkam|vanakam|namaste)\b/i.test(q),
    respond: (ctx) => ({
      text: ctx.isTanglish
        ? 'Vanakkam! Naan AICTEFlow AI Assistant (simulated). Next steps, missing documents, deadlines, risk — ellam kekunga. Oru application select pannunga.'
        : 'Hello! I am the AICTEFlow AI Assistant (simulated). Ask me about next steps, missing documents, deadlines, or delay risk. Select an application for personalized answers.',
      suggestedQuestions: SUGGESTED_QUESTIONS,
    }),
  },
];

export const SUGGESTED_QUESTIONS = [
  'What should I do next?',
  'Which documents are missing?',
  'Why is my application at risk of delay?',
  'What deadlines are approaching?',
  'How can I complete my pending tasks?',
];

function pickUrgentApp(state: StoreState): WorkflowApp | undefined {
  const ranked = state.applications
    .map((a) => ({ a, r: computeRiskForApp(a, state.tasks, state.settings) }))
    .sort((x, y) => y.r.score - x.r.score);
  return ranked[0]?.a;
}

function taskPrioritySort(a: { priority: string }, b: { priority: string }) {
  const order: Record<string, number> = { High: 0, Medium: 1, Low: 2 };
  return (order[a.priority] ?? 3) - (order[b.priority] ?? 3);
}

export function answerAssistant(query: string, state: StoreState, selectedApp?: WorkflowApp): AssistantReply {
  const tanglish = isTanglish(query);
  const ctx: AssistantContext = { query, state, selectedApp, isTanglish: tanglish };
  const intent = intents.find((i) => i.match(query));
  if (intent) return intent.respond(ctx);
  // Fallback
  return {
    text: tanglish
      ? 'Idhukku therincha answer illa. Documents, deadlines, risk, next steps pathi kekunga. Naan reliable illana "theriyala" thaan solluven — rules invented pannamatten.'
      : 'I am not sure about that. I can help with documents, deadlines, delay risk, pending tasks, and next steps. If I cannot answer reliably, I will say so rather than invent rules.',
    suggestedQuestions: SUGGESTED_QUESTIONS,
  };
}
