import type { RiskResult } from '@/lib/risk';
import type { StoreState, WorkflowApp } from '@/types';
import { missingRequiredDocs, isDocumentReady, daysToDeadline } from '@/store/useStore';
import { formatDate, formatDateTime } from '@/lib/utils';

export function generateReadinessReport(app: WorkflowApp, state: StoreState, risk: RiskResult): string {
  const lines: string[] = [];
  lines.push('========================================================');
  lines.push(' AICTEFlow — APPLICATION READINESS REPORT (Prototype)');
  lines.push('========================================================');
  lines.push('');
  lines.push(`Application ID:    ${app.id}`);
  lines.push(`Institution:       ${app.institutionName}`);
  lines.push(`Type:              ${app.applicationType}`);
  lines.push(`Status:            ${app.status}`);
  lines.push(`Created:           ${formatDate(app.createdAt)}`);
  lines.push(`Submitted:         ${formatDate(app.submittedDate)}`);
  lines.push(`Deadline:          ${formatDate(app.deadline)} (${daysToDeadline(app)} day(s) left)`);
  lines.push(`Progress:          ${app.progress}%`);
  lines.push(`Document-Ready:    ${isDocumentReady(app) ? 'Yes' : 'No — required documents missing'}`);
  lines.push('');
  lines.push('--------------------------------------------------------');
  lines.push(' DOCUMENT CHECKLIST');
  lines.push('--------------------------------------------------------');
  for (const c of app.checklist) {
    const d = app.documents.find((x) => x.type === c.type);
    const tag = c.required ? '[REQ]' : '[OPT]';
    const status = d?.status ?? 'Missing';
    const file = d?.filename ?? '—';
    lines.push(`  ${tag} ${c.type}`);
    lines.push(`       Status: ${status}   File: ${file}`);
  }
  lines.push('');
  lines.push(' Missing required documents:');
  const missing = missingRequiredDocs(app);
  if (missing.length === 0) lines.push('   None — all required documents uploaded.');
  else for (const m of missing) lines.push(`   - ${m.type}`);
  lines.push('');
  lines.push(' NOTE: "Uploaded" is a system check. "Verified" means an');
  lines.push(' authorized reviewer confirmed it. This tool does not');
  lines.push(' verify authenticity or regulatory compliance.');
  lines.push('');
  lines.push('--------------------------------------------------------');
  lines.push(' DELAY RISK ANALYSIS (Prototype estimate)');
  lines.push('--------------------------------------------------------');
  lines.push(` Risk Level: ${risk.level}   Score: ${risk.score}/100`);
  lines.push(' Contributing factors:');
  if (risk.factors.length === 0) lines.push('   None identified.');
  else for (const f of risk.factors) lines.push(`   - ${f.label} (${f.detail})`);
  lines.push(' Recommended actions (in priority order):');
  if (risk.recommendedTasks.length === 0) lines.push('   None.');
  else risk.recommendedTasks.forEach((t, i) => lines.push(`   ${i + 1}. ${t}`));
  lines.push('');
  lines.push('--------------------------------------------------------');
  lines.push(' PENDING TASKS');
  lines.push('--------------------------------------------------------');
  const tasks = state.tasks.filter((t) => t.applicationId === app.id && !t.completed);
  if (tasks.length === 0) lines.push('   No pending tasks.');
  else for (const t of tasks) {
    const assignee = state.users.find((u) => u.id === t.assigneeId);
    lines.push(`   [${t.priority}] ${t.title}`);
    lines.push(`        Due: ${formatDate(t.dueDate)}   Assignee: ${assignee?.name ?? 'Unassigned'}`);
  }
  lines.push('');
  lines.push('--------------------------------------------------------');
  lines.push(' UPCOMING DEADLINES (all applications, next 14 days)');
  lines.push('--------------------------------------------------------');
  const upcoming = state.applications.filter((a) => { const dl = daysToDeadline(a); return dl >= 0 && dl <= 14; });
  if (upcoming.length === 0) lines.push('   None in the next 14 days.');
  else for (const a of upcoming) lines.push(`   ${a.id} — ${a.institutionName} — ${formatDate(a.deadline)} (${daysToDeadline(a)}d)`);
  lines.push('');
  lines.push('--------------------------------------------------------');
  lines.push(' STATUS HISTORY');
  lines.push('--------------------------------------------------------');
  for (const h of app.history) lines.push(`   ${formatDateTime(h.date)}  ${h.status}${h.note ? ` — ${h.note}` : ''}`);
  lines.push('');
  lines.push('========================================================');
  lines.push(' DISCLAIMER: AICTEFlow is a prototype. Risk scores, AI');
  lines.push(' guidance, and reminders are simulated estimates. This');
  lines.push(' report is NOT an official AICTE document and does not');
  lines.push(' guarantee approval or compliance.');
  lines.push('========================================================');
  return lines.join('\n');
}

export function generateApplicationSummaryCSV(state: StoreState): string {
  const rows = state.applications.map((a) => {
    const missing = missingRequiredDocs(a).length;
    return {
      ApplicationID: a.id,
      Institution: a.institutionName,
      Type: a.applicationType,
      Status: a.status,
      Created: formatDate(a.createdAt),
      Deadline: formatDate(a.deadline),
      DaysLeft: daysToDeadline(a),
      Progress: `${a.progress}%`,
      MissingRequiredDocs: missing,
    };
  });
  const headers = Object.keys(rows[0] ?? {});
  const escape = (v: string | number) => { const s = String(v ?? ''); return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s; };
  return [headers.join(','), ...rows.map((r) => headers.map((h) => escape((r as Record<string, string | number>)[h])).join(','))].join('\n');
}
