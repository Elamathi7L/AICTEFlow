export type AppStatus =
  | 'Draft'
  | 'Submitted'
  | 'Under Review'
  | 'Correction Required'
  | 'Approved'
  | 'Rejected';

export type DocumentStatus = 'Uploaded' | 'Missing' | 'Needs Review' | 'Verified';

export type Priority = 'Low' | 'Medium' | 'High';

export type RiskLevel = 'Low' | 'Medium' | 'High';

export type Role = 'Administrator' | 'Institution Staff' | 'Reviewer';

export interface AppUser {
  id: string;
  name: string;
  role: Role;
  email: string;
}

export interface DocVersion {
  version: number;
  filename: string;
  uploadedAt: string;
  action: string;
}

export interface AppDocument {
  id: string;
  type: string;
  status: DocumentStatus;
  filename?: string;
  uploadedAt?: string;
  notes?: string;
  versions: DocVersion[];
}

export interface ChecklistItem {
  type: string;
  required: boolean;
}

export interface ComplianceTask {
  id: string;
  title: string;
  description?: string;
  applicationId?: string;
  assigneeId?: string;
  dueDate: string;
  priority: Priority;
  completed: boolean;
  completedAt?: string;
  createdAt: string;
}

export interface AuditEntry {
  id: string;
  timestamp: string;
  actor: string;
  action: string;
  applicationId?: string;
  details?: string;
}

export interface Alert {
  id: string;
  severity: 'info' | 'warning' | 'critical';
  date: string;
  applicationId?: string;
  message: string;
  recommendedAction: string;
  read: boolean;
  resolved: boolean;
}

export interface NotificationItem {
  id: string;
  date: string;
  message: string;
  applicationId?: string;
}

export interface WorkflowApp {
  id: string;
  institutionName: string;
  applicationType: string;
  status: AppStatus;
  submittedDate?: string;
  createdAt: string;
  deadline: string;
  progress: number;
  checklist: ChecklistItem[];
  documents: AppDocument[];
  history: { status: AppStatus; date: string; note?: string }[];
}

export interface Settings {
  reminderLeadDays: number;
  highRiskPendingTaskThreshold: number;
  mediumRiskPendingTaskThreshold: number;
  highRiskDaysToDeadline: number;
  mediumRiskDaysToDeadline: number;
  resetDataKey: string;
}

export interface StoreState {
  applications: WorkflowApp[];
  tasks: ComplianceTask[];
  alerts: Alert[];
  notifications: NotificationItem[];
  audit: AuditEntry[];
  users: AppUser[];
  settings: Settings;
}
