import { useCallback, useEffect, useRef, useState } from 'react';
import type {
  Alert,
  AppStatus,
  AppUser,
  AuditEntry,
  ComplianceTask,
  NotificationItem,
  Settings,
  StoreState,
  WorkflowApp,
} from '@/types';
import { buildSeedState, DEFAULT_USERS } from '@/data/seed';
import { computeRiskForApp } from '@/lib/risk';

const STORAGE_KEY = 'aicteflow-store-v1';

function loadState(): StoreState {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw) as StoreState;
      if (parsed.applications && parsed.settings) return parsed;
    }
  } catch {
    // fall through to seed
  }
  return buildSeedState();
}

function persist(state: StoreState) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  } catch {
    // ignore quota errors
  }
}

export function useStore() {
  const [state, setState] = useState<StoreState>(() => loadState());
  const firstRender = useRef(true);

  useEffect(() => {
    if (firstRender.current) {
      firstRender.current = false;
      return;
    }
    persist(state);
  }, [state]);

  const addAudit = useCallback(
    (actor: string, action: string, applicationId?: string, details?: string) => {
      setState((s) => ({
        ...s,
        audit: [
          {
            id: `a-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
            timestamp: new Date().toISOString(),
            actor,
            action,
            applicationId,
            details,
          },
          ...s.audit,
        ],
      }));
    },
    [],
  );

  const updateApp = useCallback((id: string, patch: Partial<WorkflowApp>) => {
    setState((s) => ({
      ...s,
      applications: s.applications.map((a) => (a.id === id ? { ...a, ...patch } : a)),
    }));
  }, []);

  const changeAppStatus = useCallback(
    (id: string, status: AppStatus, note?: string) => {
      setState((s) => ({
        ...s,
        applications: s.applications.map((a) =>
          a.id === id
            ? {
                ...a,
                status,
                submittedDate: status !== 'Draft' && !a.submittedDate ? new Date().toISOString() : a.submittedDate,
                history: [...a.history, { status, date: new Date().toISOString(), note }],
              }
            : a,
        ),
      }));
    },
    [],
  );

  const addApplication = useCallback((app: WorkflowApp) => {
    setState((s) => ({ ...s, applications: [app, ...s.applications] }));
  }, []);

  const deleteApplication = useCallback((id: string) => {
    setState((s) => ({
      ...s,
      applications: s.applications.filter((a) => a.id !== id),
      tasks: s.tasks.filter((t) => t.applicationId !== id),
      alerts: s.alerts.filter((al) => al.applicationId !== id),
    }));
  }, []);

  const uploadDocument = useCallback(
    (appId: string, docId: string, filename: string, actor: string) => {
      setState((s) => ({
        ...s,
        applications: s.applications.map((a) => {
          if (a.id !== appId) return a;
          return {
            ...a,
            documents: a.documents.map((d) => {
              if (d.id !== docId) return d;
              const nextVersion = (d.versions[d.versions.length - 1]?.version ?? 0) + 1;
              return {
                ...d,
                status: 'Uploaded',
                filename,
                uploadedAt: new Date().toISOString(),
                versions: [
                  ...d.versions,
                  {
                    version: nextVersion,
                    filename,
                    uploadedAt: new Date().toISOString(),
                    action: d.versions.length === 0 ? 'Initial upload' : 'Replaced with newer version',
                  },
                ],
              };
            }),
          };
        }),
      }));
    },
    [],
  );

  const setDocumentStatus = useCallback(
    (appId: string, docId: string, status: WorkflowApp['documents'][number]['status'], actor: string) => {
      setState((s) => ({
        ...s,
        applications: s.applications.map((a) =>
          a.id === appId
            ? {
                ...a,
                documents: a.documents.map((d) => (d.id === docId ? { ...d, status } : d)),
              }
            : a,
        ),
      }));
    },
    [],
  );

  const addTask = useCallback((task: ComplianceTask) => {
    setState((s) => ({ ...s, tasks: [task, ...s.tasks] }));
  }, []);

  const updateTask = useCallback((id: string, patch: Partial<ComplianceTask>) => {
    setState((s) => ({
      ...s,
      tasks: s.tasks.map((t) => (t.id === id ? { ...t, ...patch } : t)),
    }));
  }, []);

  const toggleTaskComplete = useCallback((id: string) => {
    setState((s) => ({
      ...s,
      tasks: s.tasks.map((t) =>
        t.id === id
          ? {
              ...t,
              completed: !t.completed,
              completedAt: !t.completed ? new Date().toISOString() : undefined,
            }
          : t,
      ),
    }));
  }, []);

  const deleteTask = useCallback((id: string) => {
    setState((s) => ({ ...s, tasks: s.tasks.filter((t) => t.id !== id) }));
  }, []);

  const addAlert = useCallback((alert: Alert) => {
    setState((s) => ({ ...s, alerts: [alert, ...s.alerts] }));
  }, []);

  const updateAlert = useCallback((id: string, patch: Partial<Alert>) => {
    setState((s) => ({
      ...s,
      alerts: s.alerts.map((a) => (a.id === id ? { ...a, ...patch } : a)),
    }));
  }, []);

  const addNotification = useCallback((n: NotificationItem) => {
    setState((s) => ({ ...s, notifications: [n, ...s.notifications].slice(0, 50) }));
  }, []);

  const updateSettings = useCallback((patch: Partial<Settings>) => {
    setState((s) => ({ ...s, settings: { ...s.settings, ...patch } }));
  }, []);

  const resetDemoData = useCallback(() => {
    const fresh = buildSeedState();
    setState(fresh);
    persist(fresh);
  }, []);

  return {
    state,
    addAudit,
    updateApp,
    changeAppStatus,
    addApplication,
    deleteApplication,
    uploadDocument,
    setDocumentStatus,
    addTask,
    updateTask,
    toggleTaskComplete,
    deleteTask,
    addAlert,
    updateAlert,
    addNotification,
    updateSettings,
    resetDemoData,
  };
}

export type StoreApi = ReturnType<typeof useStore>;

// Convenience selectors
export function missingRequiredDocs(app: WorkflowApp) {
  return app.documents.filter(
    (d) => app.checklist.find((c) => c.type === d.type)?.required && (d.status === 'Missing'),
  );
}

export function isDocumentReady(app: WorkflowApp) {
  return app.checklist.filter((c) => c.required).every((c) => {
    const d = app.documents.find((x) => x.type === c.type);
    return d && d.status !== 'Missing';
  });
}

export function daysToDeadline(app: WorkflowApp) {
  return Math.ceil((new Date(app.deadline).getTime() - Date.now()) / 86400000);
}

export { computeRiskForApp, DEFAULT_USERS };
