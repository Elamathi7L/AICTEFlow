import type {
  AppStatus,
  DocumentStatus,
  Priority,
  RiskLevel,
} from '@/types';

const statusStyles: Record<AppStatus, string> = {
  Draft: 'bg-slate-100 text-slate-700 border-slate-200',
  Submitted: 'bg-blue-50 text-blue-700 border-blue-200',
  'Under Review': 'bg-amber-50 text-amber-700 border-amber-200',
  'Correction Required': 'bg-orange-50 text-orange-700 border-orange-200',
  Approved: 'bg-emerald-50 text-emerald-700 border-emerald-200',
  Rejected: 'bg-red-50 text-red-700 border-red-200',
};

export function StatusBadge({ status }: { status: AppStatus }) {
  return (
    <span className={`inline-flex items-center rounded-full border px-2.5 py-0.5 text-xs font-medium ${statusStyles[status]}`}>
      {status}
    </span>
  );
}

const docStyles: Record<DocumentStatus, string> = {
  Uploaded: 'bg-blue-50 text-blue-700 border-blue-200',
  Missing: 'bg-red-50 text-red-700 border-red-200',
  'Needs Review': 'bg-amber-50 text-amber-700 border-amber-200',
  Verified: 'bg-emerald-50 text-emerald-700 border-emerald-200',
};

export function DocStatusBadge({ status }: { status: DocumentStatus }) {
  return (
    <span className={`inline-flex items-center rounded-full border px-2.5 py-0.5 text-xs font-medium ${docStyles[status]}`}>
      {status}
    </span>
  );
}

const priorityStyles: Record<Priority, string> = {
  Low: 'bg-slate-100 text-slate-600 border-slate-200',
  Medium: 'bg-amber-50 text-amber-700 border-amber-200',
  High: 'bg-red-50 text-red-700 border-red-200',
};

export function PriorityBadge({ priority }: { priority: Priority }) {
  return (
    <span className={`inline-flex items-center rounded-full border px-2 py-0.5 text-xs font-medium ${priorityStyles[priority]}`}>
      {priority}
    </span>
  );
}

const riskStyles: Record<RiskLevel, string> = {
  Low: 'bg-emerald-50 text-emerald-700 border-emerald-200',
  Medium: 'bg-amber-50 text-amber-700 border-amber-200',
  High: 'bg-red-50 text-red-700 border-red-200',
};

const riskDot: Record<RiskLevel, string> = {
  Low: 'bg-emerald-500',
  Medium: 'bg-amber-500',
  High: 'bg-red-500',
};

export function RiskBadge({ level, score }: { level: RiskLevel; score?: number }) {
  return (
    <span className={`inline-flex items-center gap-1.5 rounded-full border px-2.5 py-0.5 text-xs font-medium ${riskStyles[level]}`}>
      <span className={`h-1.5 w-1.5 rounded-full ${riskDot[level]}`} />
      {level}{score !== undefined ? ` · ${score}` : ''}
    </span>
  );
}

export function ProgressBar({ value }: { value: number }) {
  const v = Math.max(0, Math.min(100, value));
  const color = v >= 80 ? 'bg-emerald-500' : v >= 40 ? 'bg-blue-500' : 'bg-amber-500';
  return (
    <div className="h-2 w-full rounded-full bg-slate-200 overflow-hidden">
      <div className={`h-full ${color} transition-all duration-500`} style={{ width: `${v}%` }} />
    </div>
  );
}

export function Avatar({ name, size = 'md' }: { name: string; size?: 'sm' | 'md' }) {
  const initials = name.split(' ').map((p) => p[0]).slice(0, 2).join('').toUpperCase();
  const sz = size === 'sm' ? 'h-7 w-7 text-xs' : 'h-9 w-9 text-sm';
  const palette = ['bg-blue-600', 'bg-emerald-600', 'bg-violet-600', 'bg-amber-600', 'bg-rose-600'];
  const idx = name.charCodeAt(0) % palette.length;
  return (
    <span className={`inline-flex items-center justify-center rounded-full ${palette[idx]} text-white font-semibold ${sz}`}>
      {initials}
    </span>
  );
}
