import { Menu, Bell, AlertTriangle } from 'lucide-react';
import { useState } from 'react';
import type { Alert } from '@/types';
import { relativeDays } from '@/lib/utils';
import { classNames } from '@/lib/utils';

interface Props {
  title: string;
  subtitle?: string;
  alerts: Alert[];
  onMarkRead: (id: string) => void;
  onOpenSidebar: () => void;
}

export function Header({ title, subtitle, alerts, onMarkRead, onOpenSidebar }: Props) {
  const [open, setOpen] = useState(false);
  const unread = alerts.filter((a) => !a.read);

  return (
    <header className="sticky top-0 z-20 bg-white/90 backdrop-blur border-b border-slate-200">
      <div className="flex items-center justify-between gap-4 px-4 sm:px-6 py-3.5">
        <div className="flex items-center gap-3 min-w-0">
          <button onClick={onOpenSidebar} className="lg:hidden text-slate-600 hover:text-slate-900">
            <Menu className="h-6 w-6" />
          </button>
          <div className="min-w-0">
            <h1 className="text-lg sm:text-xl font-bold text-slate-900 truncate">{title}</h1>
            {subtitle && <p className="text-xs sm:text-sm text-slate-500 truncate">{subtitle}</p>}
          </div>
        </div>

        <div className="relative">
          <button
            onClick={() => setOpen((o) => !o)}
            className="relative p-2 rounded-lg text-slate-600 hover:bg-slate-100"
            aria-label="Notifications"
          >
            <Bell className="h-5 w-5" />
            {unread.length > 0 && (
              <span className="absolute top-1 right-1 h-4 min-w-4 px-1 rounded-full bg-red-500 text-white text-[10px] font-bold flex items-center justify-center">
                {unread.length}
              </span>
            )}
          </button>

          {open && (
            <>
              <div className="fixed inset-0 z-30" onClick={() => setOpen(false)} />
              <div className="absolute right-0 mt-2 w-80 sm:w-96 card z-40 max-h-[70vh] flex flex-col animate-slide-up">
                <div className="px-4 py-3 border-b border-slate-200 flex items-center justify-between">
                  <p className="font-semibold text-sm text-slate-900">Alerts & Notifications</p>
                  <span className="text-xs text-slate-500">{unread.length} unread</span>
                </div>
                <div className="overflow-y-auto flex-1">
                  {alerts.length === 0 && (
                    <p className="text-sm text-slate-500 px-4 py-6 text-center">No alerts.</p>
                  )}
                  {alerts.slice(0, 12).map((a) => {
                    const sev = a.severity === 'critical' ? 'text-red-600 bg-red-50' : a.severity === 'warning' ? 'text-amber-600 bg-amber-50' : 'text-blue-600 bg-blue-50';
                    return (
                      <div key={a.id} className={classNames('px-4 py-3 border-b border-slate-100', !a.read && 'bg-blue-50/40')}>
                        <div className="flex items-start gap-2">
                          <span className={classNames('mt-0.5 rounded-md p-1', sev)}>
                            <AlertTriangle className="h-3.5 w-3.5" />
                          </span>
                          <div className="flex-1 min-w-0">
                            <p className="text-sm text-slate-800 leading-snug">{a.message}</p>
                            <p className="text-xs text-slate-500 mt-0.5">{relativeDays(a.date)} · {a.recommendedAction}</p>
                          </div>
                        </div>
                        {!a.read && (
                          <button onClick={() => onMarkRead(a.id)} className="mt-1.5 text-xs text-blue-600 hover:underline">
                            Mark read
                          </button>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>
            </>
          )}
        </div>
      </div>
    </header>
  );
}
