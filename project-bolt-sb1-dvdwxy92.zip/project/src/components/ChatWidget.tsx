import { Bot, Send, X, MessageSquare } from 'lucide-react';
import { useEffect, useRef, useState } from 'react';
import type { StoreState, WorkflowApp } from '@/types';
import { answerAssistant, SUGGESTED_QUESTIONS, type AssistantReply } from '@/lib/assistant';

interface ChatMessage {
  id: number;
  role: 'user' | 'assistant';
  text: string;
  relatedAppId?: string;
  suggestions?: string[];
}

interface Props {
  state: StoreState;
  selectedApp?: WorkflowApp;
  onJumpToApp?: (id: string) => void;
}

let msgId = 1;

export function ChatWidget({ state, selectedApp, onJumpToApp }: Props) {
  const [open, setOpen] = useState(false);
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: msgId++,
      role: 'assistant',
      text: 'Vanakkam! I am the AICTEFlow AI Assistant (simulated, rule-based). Ask me about next steps, missing documents, deadlines, or delay risk. I support English and Tanglish.',
      suggestions: SUGGESTED_QUESTIONS,
    },
  ]);
  const [input, setInput] = useState('');
  const endRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (open) endRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, open]);

  const send = (text: string) => {
    if (!text.trim()) return;
    const userMsg: ChatMessage = { id: msgId++, role: 'user', text };
    const reply: AssistantReply = answerAssistant(text, state, selectedApp);
    const botMsg: ChatMessage = {
      id: msgId++,
      role: 'assistant',
      text: reply.text,
      relatedAppId: reply.relatedAppId,
      suggestions: reply.suggestedQuestions,
    };
    setMessages((m) => [...m, userMsg, botMsg]);
    setInput('');
  };

  return (
    <>
      {!open && (
        <button
          onClick={() => setOpen(true)}
          className="fixed bottom-5 right-5 z-40 flex items-center gap-2 rounded-full bg-blue-600 text-white shadow-lg px-4 py-3 hover:bg-blue-700 transition-all hover:scale-105"
          aria-label="Open AI Assistant"
        >
          <Bot className="h-5 w-5" />
          <span className="text-sm font-medium hidden sm:inline">AI Assistant</span>
        </button>
      )}

      {open && (
        <div className="fixed bottom-5 right-5 z-40 w-[min(380px,calc(100vw-2.5rem))] h-[min(560px,calc(100vh-3rem))] card flex flex-col animate-slide-up">
          <div className="flex items-center justify-between bg-blue-600 text-white px-4 py-3 rounded-t-xl">
            <div className="flex items-center gap-2">
              <Bot className="h-5 w-5" />
              <div>
                <p className="font-semibold text-sm">AI Assistant</p>
                <p className="text-[11px] text-blue-100">Simulated · English & Tanglish</p>
              </div>
            </div>
            <button onClick={() => setOpen(false)} className="text-blue-100 hover:text-white rounded p-1 hover:bg-blue-500">
              <X className="h-5 w-5" />
            </button>
          </div>

          <div className="flex-1 overflow-y-auto px-3 py-3 space-y-3 bg-slate-50">
            {messages.map((m) => (
              <div key={m.id} className={m.role === 'user' ? 'flex justify-end' : 'flex justify-start'}>
                <div className={`max-w-[85%] ${m.role === 'user' ? 'bg-blue-600 text-white' : 'bg-white border border-slate-200 text-slate-700'} rounded-lg px-3 py-2 text-sm whitespace-pre-line shadow-sm`}>
                  {m.role === 'assistant' && (
                    <div className="flex items-center gap-1.5 mb-1 text-blue-600">
                      <MessageSquare className="h-3.5 w-3.5" />
                      <span className="text-[10px] font-semibold uppercase tracking-wide">Assistant</span>
                    </div>
                  )}
                  <p className="leading-relaxed">{m.text}</p>
                  {m.relatedAppId && onJumpToApp && (
                    <button
                      onClick={() => { onJumpToApp(m.relatedAppId!); setOpen(false); }}
                      className="mt-2 text-xs underline text-blue-600 hover:text-blue-800"
                    >
                      View {m.relatedAppId}
                    </button>
                  )}
                  {m.suggestions && m.suggestions.length > 0 && (
                    <div className="mt-2 flex flex-wrap gap-1.5">
                      {m.suggestions.map((s) => (
                        <button
                          key={s}
                          onClick={() => send(s)}
                          className="text-[11px] rounded-full bg-slate-100 hover:bg-blue-100 text-slate-700 hover:text-blue-700 px-2 py-0.5 border border-slate-200"
                        >
                          {s}
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            ))}
            <div ref={endRef} />
          </div>

          <form
            onSubmit={(e) => { e.preventDefault(); send(input); }}
            className="flex items-center gap-2 border-t border-slate-200 p-2 bg-white rounded-b-xl"
          >
            <input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Ask in English or Tanglish…"
              className="flex-1 text-sm px-3 py-2 rounded-lg border border-slate-300 focus:border-blue-500 focus:ring-1 focus:ring-blue-500 outline-none"
            />
            <button type="submit" className="bg-blue-600 text-white rounded-lg p-2 hover:bg-blue-700 transition-colors" aria-label="Send">
              <Send className="h-4 w-4" />
            </button>
          </form>
        </div>
      )}
    </>
  );
}
