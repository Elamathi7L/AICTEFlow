import {
  LayoutDashboard,
  FolderKanban,
  FileText,
  CalendarCheck,
  BarChart3,
  History,
  Settings as SettingsIcon,
  Bot,
  ShieldCheck,
  X,
} from 'lucide-react';
import { classNames } from '@/lib/utils';

export type PageKey =
  | 'dashboard'
  | 'applications'
  | 'documents'
  | 'calendar'
  | 'reports'
  | 'audit'
  | 'settings';

interface NavItem {
  key: PageKey;
  label: string;
  icon: typeof LayoutDashboard;
}

const NAV: NavItem[] = [
  { key: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { key: 'applications', label: 'Applications', icon: FolderKanban },
  { key: 'documents', label: 'Documents', icon: FileText },
  { key: 'calendar', label: 'Compliance Calendar', icon: CalendarCheck },
  { key: 'reports', label: 'Reports', icon: BarChart3 },
  { key: 'audit', label: 'Audit Trail', icon: History },
  { key: 'settings', label: 'Settings', icon: SettingsIcon },
];

interface Props {
  current: PageKey;
  onNavigate: (page: PageKey) => void;
  open: boolean;
  onClose: () => void;
}

export function Sidebar({ current, onNavigate, open, onClose }: Props) {
  return (
    <>
      {open && <div className="fixed inset-0 z-30 bg-slate-900/40 lg:hidden" onClick={onClose} />}
      <aside
        className={classNames(
          'fixed lg:static z-40 inset-y-0 left-0 w-64 bg-slate-900 text-slate-300 flex flex-col transition-transform lg:translate-x-0',
          open ? 'translate-x-0' : '-translate-x-full',
        )}
      >
        <div className="flex items-center justify-between px-5 py-5 border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="h-9 w-9 rounded-lg bg-blue-600 flex items-center justify-center">
              <ShieldCheck className="h-5 w-5 text-white" />
            </div>
            <div>
              <p className="text-white font-bold text-base leading-none">AICTEFlow</p>
              <p className="text-[10px] text-slate-400 mt-0.5">Workflow & Compliance</p>
            </div>
          </div>
          <button onClick={onClose} className="lg:hidden text-slate-400 hover:text-white">
            <X className="h-5 w-5" />
          </button>
        </div>

        <nav className="flex-1 px-3 py-4 space-y-1 overflow-y-auto">
          {NAV.map((item) => {
            const Icon = item.icon;
            const active = current === item.key;
            return (
              <button
                key={item.key}
                onClick={() => onNavigate(item.key)}
                className={classNames(
                  'w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors',
                  active
                    ? 'bg-blue-600 text-white shadow-sm'
                    : 'text-slate-300 hover:bg-slate-800 hover:text-white',
                )}
              >
                <Icon className="h-5 w-5 flex-shrink-0" />
                {item.label}
              </button>
            );
          })}
        </nav>

        <div className="border-t border-slate-800 p-4">
          <div className="rounded-lg bg-slate-800/60 p-3">
            <div className="flex items-center gap-2 text-blue-400 mb-1.5">
              <Bot className="h-4 w-4" />
              <span className="text-xs font-semibold">AI Assistant</span>
            </div>
            <p className="text-[11px] text-slate-400 leading-relaxed">
              Simulated, rule-based guide. Estimates are prototype only.
            </p>
          </div>
        </div>
      </aside>
    </>
  );
}
