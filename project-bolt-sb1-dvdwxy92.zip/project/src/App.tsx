import { useState } from 'react';
import { useStore } from '@/store/useStore';
import { ToastProvider } from '@/components/Toast';
import { Sidebar, type PageKey } from '@/components/Sidebar';
import { Header } from '@/components/Header';
import { ChatWidget } from '@/components/ChatWidget';
import { Dashboard } from '@/pages/Dashboard';
import { ApplicationsPage } from '@/pages/ApplicationsPage';
import { ApplicationDetail } from '@/pages/ApplicationDetail';
import { DocumentsPage } from '@/pages/DocumentsPage';
import { CalendarPage } from '@/pages/CalendarPage';
import { ReportsPage } from '@/pages/ReportsPage';
import { AuditPage } from '@/pages/AuditPage';
import { SettingsPage } from '@/pages/SettingsPage';
import type { WorkflowApp } from '@/types';


function AppInner() {
  const store = useStore();
  const [page, setPage] = useState<PageKey>('dashboard');
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [openAppId, setOpenAppId] = useState<string | null>(null);

  const navigate = (p: PageKey) => {
    setPage(p);
    setOpenAppId(null);
    setSidebarOpen(false);
  };

  const openApp = (id: string) => {
    setOpenAppId(id);
    setSidebarOpen(false);
  };

  const handleCreate = (app: WorkflowApp) => {
    store.addApplication(app);
    store.addAudit('Current User', `Application created: ${app.institutionName} (${app.id})`, app.id);
    setOpenAppId(app.id);
  };

  const handleDelete = (id: string) => {
    store.deleteApplication(id);
    if (openAppId === id) setOpenAppId(null);
  };

  const titles: Record<PageKey, { title: string; subtitle: string }> = {
    dashboard: { title: 'Dashboard', subtitle: 'Overview of applications, risk, and activity' },
    applications: { title: 'Applications', subtitle: 'Institution application workflows' },
    documents: { title: 'Documents', subtitle: 'Checklist and document tracking' },
    calendar: { title: 'Compliance Calendar', subtitle: 'Tasks, deadlines, and reminders' },
    reports: { title: 'Reports', subtitle: 'Summaries and exports' },
    audit: { title: 'Audit Trail', subtitle: 'Recorded actions and changes' },
    settings: { title: 'Settings', subtitle: 'Risk thresholds, roles, and demo data' },
  };

  const selectedApp = openAppId ? store.state.applications.find((a) => a.id === openAppId) : undefined;

  return (
    <div className="flex h-screen overflow-hidden bg-slate-50">
      <Sidebar current={page} onNavigate={navigate} open={sidebarOpen} onClose={() => setSidebarOpen(false)} />
      <div className="flex-1 flex flex-col overflow-hidden">
        <Header
          title={openAppId ? 'Application Detail' : titles[page].title}
          subtitle={openAppId ? selectedApp?.institutionName : titles[page].subtitle}
          alerts={store.state.alerts}
          onMarkRead={(id) => store.updateAlert(id, { read: true })}
          onOpenSidebar={() => setSidebarOpen(true)}
        />
        <main className="flex-1 overflow-y-auto">
          {openAppId ? (
            <ApplicationDetail appId={openAppId} store={store} onBack={() => setOpenAppId(null)} onNavigate={(p) => navigate(p)} />
          ) : (
            <>
              {page === 'dashboard' && <Dashboard state={store.state} onOpenApp={openApp} onNavigate={(p) => navigate(p as PageKey)} />}
              {page === 'applications' && <ApplicationsPage state={store.state} onOpenApp={openApp} onCreate={handleCreate} onDelete={handleDelete} />}
              {page === 'documents' && <DocumentsPage state={store.state} store={store} onOpenApp={openApp} />}
              {page === 'calendar' && <CalendarPage state={store.state} store={store} onOpenApp={openApp} />}
              {page === 'reports' && <ReportsPage state={store.state} store={store} />}
              {page === 'audit' && <AuditPage state={store.state} onOpenApp={openApp} />}
              {page === 'settings' && <SettingsPage store={store} />}
            </>
          )}
        </main>
      </div>
      <ChatWidget state={store.state} selectedApp={selectedApp} onJumpToApp={openApp} />
    </div>
  );
}

export default function App() {
  return (
    <ToastProvider>
      <AppInner />
    </ToastProvider>
  );
}
